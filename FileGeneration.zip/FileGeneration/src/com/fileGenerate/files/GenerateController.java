package com.fileGenerate.files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * @author varma
 * */

public class GenerateController {

	public static void main(String[] args) {

		String[] files = { "_Controller", /* "_BusinessDelegate", */ "_Model", "I_Service",
				"_Service" /* "_Repository", */
				/* "_Context" *//* , "_To_ModelConverter", "_ModelTo_Converter" */ };
		/* String[] files = {"_To_ModelConverter","_ModelTo_Converter" }; */
		for (String fileName : args) {
			for (String file : files) {
				try {
					FileReader src = new FileReader("./sampleTemplates/" + file + ".txt");
					String searchC = "CAPSCONSTANT";
					String searchS = "SMALLCONSTANT";
					String s;
					String totalStr = "";
					String caps = fileName;
					String small = fileName.replaceFirst(fileName.substring(0, 1),
							fileName.substring(0, 1).toLowerCase());
					try (BufferedReader br = new BufferedReader(src)) {
						while ((s = br.readLine()) != null) {
							totalStr += s + "\r\n";
						}
						totalStr = totalStr.replaceAll(searchC, caps);
						totalStr = totalStr.replaceAll(searchS, small);
						FileWriter dest = new FileWriter(
								"./destination/" + file + "/" + file.replace("_", fileName) + ".java");
						dest.write(totalStr);
						dest.close();
					} catch (Exception e) {
					}
//					E:\ip-pos\CodeBase2\IM-POS\impos-promotions\src\main\java\com
					String paths = "E:/ip-pos/CodeBase2/IM-POS/impos-reports/src/main/java/com/impos/reports/";

					if (paths != null) {
						switch (file) {
						case "_Controller":
							String[] obs = paths.split(("java/"));
							String packages = obs[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replaceAll("packageName", packages + "_Controller".replace("_C", "c")),
									paths + file.replace("_C", "c"));

							break;

						case "_BusinessDelegate":
							String[] businessDel = paths.split(("java/"));
							String businessDelPackages = businessDel[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName",
											businessDelPackages + "_BusinessDelegate".replace("_B", "b").toLowerCase()),
									paths + file.replace("_B", "b").toLowerCase());

							break;

						case "I_Service":

							String[] iService = paths.split(("java/"));
							String iServicePackages = iService[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName", iServicePackages + file.replace("I_S", "s")),

									paths + file.replace("I_S", "s"));

							break;

						case "_Service":

							String[] service = paths.split(("java/"));
							String servicePackages = service[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName", servicePackages + file.replace("_S", "s")),
									paths + file.replace("_S", "s"));

							break;

						case "_Context":

							String[] context = paths.split(("java/"));
							String contextPackages = context[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName",
											contextPackages + "businessdelegate." + file.replace("_C", "c")),
									paths + "_BusinessDelegate".replace("_B", "b").toLowerCase() + "/"
											+ file.replace("_C", "c"));

							break;

						case "_To_ModelConverter":

							String[] converter = paths.split(("java/"));
							String converterPackages = converter[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName", converterPackages + "model.converters"),
									paths + "model/converters");
							break;

						case "_ModelTo_Converter":

							String[] modelToDomain = paths.split(("java/"));
							String modelToDomainPackages = modelToDomain[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName", modelToDomainPackages + "model.converters"),
									paths + "model/converters");

							break;

						case "_Model":

							String[] model = paths.split("java/");

							String modalPackage = model[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName", modalPackage + file.replace("_M", "m")),
									paths + file.replace("_M", "m"));

							break;

						case "_Repository":

							String[] repository = paths.split("java/");

							String repositoryPackage = repository[1].toString().replace('/', '.');

							extracted(fileName, file,
									totalStr.replace("packageName", repositoryPackage + file.replace("_R", "r")),
									paths + file.replace("_R", "r"));

							break;

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		}

		// try {
		//
		// InetAddress icon = InetAddress.getLocalHost();
		// System.err.println("hi " + icon.getCanonicalHostName());
		// System.err.println("varma " + icon.getHostAddress());
		// NetworkInterface net = NetworkInterface.getByInetAddress(icon);
		//
		// byte[] mac = net.getHardwareAddress();
		// StringBuffer sb = new StringBuffer();
		// for (int i = 0; i < mac.length; i++) {
		// sb.append(String.format("%02X%s", mac[i],
		// (i < mac.length - 1) ? "-" : ""));
		// }
		// System.err.println("mac " + sb.toString());
		//
		// } catch (UnknownHostException e) {
		// e.printStackTrace();
		// } catch (SocketException e) {
		// e.printStackTrace();
		// }

		System.out.println("That's it...");
	}

	private static void extracted(String fileName, String file, String totalStr, String paths) throws IOException {
		File files = new File(paths);

		if (files.exists()) {
			FileWriter dest = new FileWriter(paths + "/" + file.replace("_", fileName) + ".java");

			dest.write(totalStr);

			dest.flush();
			dest.close();
		} else {
			files.mkdirs();

			FileWriter dest = new FileWriter(paths + "/" + file.replace("_", fileName) + ".java");
			dest.write(totalStr);
			dest.close();

		}

	}
}