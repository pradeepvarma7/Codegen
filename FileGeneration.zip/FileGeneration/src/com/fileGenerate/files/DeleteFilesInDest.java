package com.fileGenerate.files;

import java.io.File;

public class DeleteFilesInDest {

	public static void main(String[] args) {
		String dest = "./destination";
		File file = new File(dest);

		String[] filesNames = file.list();

		for (String names : filesNames) {

			File file1 = new File(dest + "/" + names);

			String[] innerFiles = file1.list();

			for (String inner : innerFiles) {

//				System.err.println("inner " + inner);

				System.err.println(file1.getAbsolutePath() + "/" + inner);

				File deleteFile = new File(file1.getAbsolutePath() + "/" + inner);

				if (deleteFile.delete()) {

					System.err.println("Delete " + inner);
				} else {

					System.err.println("ERROR");
				}

			}

			System.err.println(names);
		}

	}

}
