package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class GrnItemsBusinessDelegate
		implements IBusinessDelegate<GrnItemsModel, GrnItemsContext, IKeyBuilder<String>, String> {

	@Autowired
	private IGrnItemsService grnItemsService;
	@Autowired
	private ConversionService conversionService;
@Autowired
GrnItemsModelToGrnItemsConverter tempGrnItemsModelToGrnItemsConverter;
@Autowired
GrnItemsToGrnItemsModelConverter tempGrnItemsToGrnItemsModelConverter;

	@Override
	@Transactional
	public GrnItemsModel create(GrnItemsModel model) {
model = tempGrnItemsToGrnItemsModelConverter.convert(grnItemsService.create(tempGrnItemsModelToGrnItemsConverter.convert(model)));
		
		return model;
	}
	
	private GrnItemsModel convertToGrnItemsModel(
			GrnItems grnItems) {
		return (GrnItemsModel) conversionService.convert(
				grnItems, forObject(grnItems),
				valueOf(GrnItemsModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, GrnItemsContext context) {

	}

	@Override
	public GrnItemsModel edit(IKeyBuilder<String> keyBuilder, GrnItemsModel model) {
		GrnItems grnItems = grnItemsService.getGrnItems(keyBuilder.build().toString());
		model = tempGrnItemsToGrnItemsModelConverter.convert(grnItemsService.updateGrnItems(tempGrnItemsModelToGrnItemsConverter.convert(model)));
		
		return model;
	}

	@Override
	public GrnItemsModel getByKey(IKeyBuilder<String> keyBuilder, GrnItemsContext context) {
		GrnItems grnItems = grnItemsService.getGrnItems(keyBuilder.build().toString());
		GrnItemsModel model =tempGrnItemsToGrnItemsModelConverter.convert(grnItems);
		return model;
	}

	@Override
	public Collection<GrnItemsModel> getCollection(GrnItemsContext context) {
		List<GrnItemsModel> grnItemsModels = new ArrayList<GrnItemsModel>();
		
		for(GrnItems grnItems : grnItemsService.getAll(context)){
		
		grnItemsModels.add(tempGrnItemsToGrnItemsModelConverter.convert(grnItems));
		}
		
		
		
		return grnItemsModels;
	}

@Override
	public GrnItemsModel edit(IKeyBuilder<String> keyBuilder, GrnItemsModel model, GrnItemsContext context) {
		return null;
	}



}
