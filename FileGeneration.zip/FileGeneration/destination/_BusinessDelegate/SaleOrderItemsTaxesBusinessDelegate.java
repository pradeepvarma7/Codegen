package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class SaleOrderItemsTaxesBusinessDelegate
		implements IBusinessDelegate<SaleOrderItemsTaxesModel, SaleOrderItemsTaxesContext, IKeyBuilder<String>, String> {

	@Autowired
	private ISaleOrderItemsTaxesService saleOrderItemsTaxesService;
	@Autowired
	private ConversionService conversionService;
@Autowired
SaleOrderItemsTaxesModelToSaleOrderItemsTaxesConverter tempSaleOrderItemsTaxesModelToSaleOrderItemsTaxesConverter;
@Autowired
SaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter tempSaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter;

	@Override
	@Transactional
	public SaleOrderItemsTaxesModel create(SaleOrderItemsTaxesModel model) {
model = tempSaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter.convert(saleOrderItemsTaxesService.create(tempSaleOrderItemsTaxesModelToSaleOrderItemsTaxesConverter.convert(model)));
		
		return model;
	}
	
	private SaleOrderItemsTaxesModel convertToSaleOrderItemsTaxesModel(
			SaleOrderItemsTaxes saleOrderItemsTaxes) {
		return (SaleOrderItemsTaxesModel) conversionService.convert(
				saleOrderItemsTaxes, forObject(saleOrderItemsTaxes),
				valueOf(SaleOrderItemsTaxesModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, SaleOrderItemsTaxesContext context) {

	}

	@Override
	public SaleOrderItemsTaxesModel edit(IKeyBuilder<String> keyBuilder, SaleOrderItemsTaxesModel model) {
		SaleOrderItemsTaxes saleOrderItemsTaxes = saleOrderItemsTaxesService.getSaleOrderItemsTaxes(keyBuilder.build().toString());
		model = tempSaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter.convert(saleOrderItemsTaxesService.updateSaleOrderItemsTaxes(tempSaleOrderItemsTaxesModelToSaleOrderItemsTaxesConverter.convert(model)));
		
		return model;
	}

	@Override
	public SaleOrderItemsTaxesModel getByKey(IKeyBuilder<String> keyBuilder, SaleOrderItemsTaxesContext context) {
		SaleOrderItemsTaxes saleOrderItemsTaxes = saleOrderItemsTaxesService.getSaleOrderItemsTaxes(keyBuilder.build().toString());
		SaleOrderItemsTaxesModel model =tempSaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter.convert(saleOrderItemsTaxes);
		return model;
	}

	@Override
	public Collection<SaleOrderItemsTaxesModel> getCollection(SaleOrderItemsTaxesContext context) {
		List<SaleOrderItemsTaxesModel> saleOrderItemsTaxesModels = new ArrayList<SaleOrderItemsTaxesModel>();
		
		for(SaleOrderItemsTaxes saleOrderItemsTaxes : saleOrderItemsTaxesService.getAll(context)){
		
		saleOrderItemsTaxesModels.add(tempSaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter.convert(saleOrderItemsTaxes));
		}
		
		
		
		return saleOrderItemsTaxesModels;
	}

@Override
	public SaleOrderItemsTaxesModel edit(IKeyBuilder<String> keyBuilder, SaleOrderItemsTaxesModel model, SaleOrderItemsTaxesContext context) {
		return null;
	}



}
