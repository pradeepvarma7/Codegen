package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class GrnItemsTaxesBusinessDelegate
		implements IBusinessDelegate<GrnItemsTaxesModel, GrnItemsTaxesContext, IKeyBuilder<String>, String> {

	@Autowired
	private IGrnItemsTaxesService grnItemsTaxesService;
	@Autowired
	private ConversionService conversionService;
@Autowired
GrnItemsTaxesModelToGrnItemsTaxesConverter tempGrnItemsTaxesModelToGrnItemsTaxesConverter;
@Autowired
GrnItemsTaxesToGrnItemsTaxesModelConverter tempGrnItemsTaxesToGrnItemsTaxesModelConverter;

	@Override
	@Transactional
	public GrnItemsTaxesModel create(GrnItemsTaxesModel model) {
model = tempGrnItemsTaxesToGrnItemsTaxesModelConverter.convert(grnItemsTaxesService.create(tempGrnItemsTaxesModelToGrnItemsTaxesConverter.convert(model)));
		
		return model;
	}
	
	private GrnItemsTaxesModel convertToGrnItemsTaxesModel(
			GrnItemsTaxes grnItemsTaxes) {
		return (GrnItemsTaxesModel) conversionService.convert(
				grnItemsTaxes, forObject(grnItemsTaxes),
				valueOf(GrnItemsTaxesModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, GrnItemsTaxesContext context) {

	}

	@Override
	public GrnItemsTaxesModel edit(IKeyBuilder<String> keyBuilder, GrnItemsTaxesModel model) {
		GrnItemsTaxes grnItemsTaxes = grnItemsTaxesService.getGrnItemsTaxes(keyBuilder.build().toString());
		model = tempGrnItemsTaxesToGrnItemsTaxesModelConverter.convert(grnItemsTaxesService.updateGrnItemsTaxes(tempGrnItemsTaxesModelToGrnItemsTaxesConverter.convert(model)));
		
		return model;
	}

	@Override
	public GrnItemsTaxesModel getByKey(IKeyBuilder<String> keyBuilder, GrnItemsTaxesContext context) {
		GrnItemsTaxes grnItemsTaxes = grnItemsTaxesService.getGrnItemsTaxes(keyBuilder.build().toString());
		GrnItemsTaxesModel model =tempGrnItemsTaxesToGrnItemsTaxesModelConverter.convert(grnItemsTaxes);
		return model;
	}

	@Override
	public Collection<GrnItemsTaxesModel> getCollection(GrnItemsTaxesContext context) {
		List<GrnItemsTaxesModel> grnItemsTaxesModels = new ArrayList<GrnItemsTaxesModel>();
		
		for(GrnItemsTaxes grnItemsTaxes : grnItemsTaxesService.getAll(context)){
		
		grnItemsTaxesModels.add(tempGrnItemsTaxesToGrnItemsTaxesModelConverter.convert(grnItemsTaxes));
		}
		
		
		
		return grnItemsTaxesModels;
	}

@Override
	public GrnItemsTaxesModel edit(IKeyBuilder<String> keyBuilder, GrnItemsTaxesModel model, GrnItemsTaxesContext context) {
		return null;
	}



}
