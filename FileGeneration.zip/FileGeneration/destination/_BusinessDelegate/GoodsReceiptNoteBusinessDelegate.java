package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class GoodsReceiptNoteBusinessDelegate
		implements IBusinessDelegate<GoodsReceiptNoteModel, GoodsReceiptNoteContext, IKeyBuilder<String>, String> {

	@Autowired
	private IGoodsReceiptNoteService goodsReceiptNoteService;
	@Autowired
	private ConversionService conversionService;
@Autowired
GoodsReceiptNoteModelToGoodsReceiptNoteConverter tempGoodsReceiptNoteModelToGoodsReceiptNoteConverter;
@Autowired
GoodsReceiptNoteToGoodsReceiptNoteModelConverter tempGoodsReceiptNoteToGoodsReceiptNoteModelConverter;

	@Override
	@Transactional
	public GoodsReceiptNoteModel create(GoodsReceiptNoteModel model) {
model = tempGoodsReceiptNoteToGoodsReceiptNoteModelConverter.convert(goodsReceiptNoteService.create(tempGoodsReceiptNoteModelToGoodsReceiptNoteConverter.convert(model)));
		
		return model;
	}
	
	private GoodsReceiptNoteModel convertToGoodsReceiptNoteModel(
			GoodsReceiptNote goodsReceiptNote) {
		return (GoodsReceiptNoteModel) conversionService.convert(
				goodsReceiptNote, forObject(goodsReceiptNote),
				valueOf(GoodsReceiptNoteModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, GoodsReceiptNoteContext context) {

	}

	@Override
	public GoodsReceiptNoteModel edit(IKeyBuilder<String> keyBuilder, GoodsReceiptNoteModel model) {
		GoodsReceiptNote goodsReceiptNote = goodsReceiptNoteService.getGoodsReceiptNote(keyBuilder.build().toString());
		model = tempGoodsReceiptNoteToGoodsReceiptNoteModelConverter.convert(goodsReceiptNoteService.updateGoodsReceiptNote(tempGoodsReceiptNoteModelToGoodsReceiptNoteConverter.convert(model)));
		
		return model;
	}

	@Override
	public GoodsReceiptNoteModel getByKey(IKeyBuilder<String> keyBuilder, GoodsReceiptNoteContext context) {
		GoodsReceiptNote goodsReceiptNote = goodsReceiptNoteService.getGoodsReceiptNote(keyBuilder.build().toString());
		GoodsReceiptNoteModel model =tempGoodsReceiptNoteToGoodsReceiptNoteModelConverter.convert(goodsReceiptNote);
		return model;
	}

	@Override
	public Collection<GoodsReceiptNoteModel> getCollection(GoodsReceiptNoteContext context) {
		List<GoodsReceiptNoteModel> goodsReceiptNoteModels = new ArrayList<GoodsReceiptNoteModel>();
		
		for(GoodsReceiptNote goodsReceiptNote : goodsReceiptNoteService.getAll(context)){
		
		goodsReceiptNoteModels.add(tempGoodsReceiptNoteToGoodsReceiptNoteModelConverter.convert(goodsReceiptNote));
		}
		
		
		
		return goodsReceiptNoteModels;
	}

@Override
	public GoodsReceiptNoteModel edit(IKeyBuilder<String> keyBuilder, GoodsReceiptNoteModel model, GoodsReceiptNoteContext context) {
		return null;
	}



}
