package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class AddressBusinessDelegate
		implements IBusinessDelegate<AddressModel, AddressContext, IKeyBuilder<String>, String> {

	@Autowired
	private IAddressService addressService;
	@Autowired
	private ConversionService conversionService;
@Autowired
AddressModelToAddressConverter tempAddressModelToAddressConverter;
@Autowired
AddressToAddressModelConverter tempAddressToAddressModelConverter;

	@Override
	@Transactional
	public AddressModel create(AddressModel model) {
model = tempAddressToAddressModelConverter.convert(addressService.create(tempAddressModelToAddressConverter.convert(model)));
		
		return model;
	}
	
	private AddressModel convertToAddressModel(
			Address address) {
		return (AddressModel) conversionService.convert(
				address, forObject(address),
				valueOf(AddressModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, AddressContext context) {

	}

	@Override
	public AddressModel edit(IKeyBuilder<String> keyBuilder, AddressModel model) {
		Address address = addressService.getAddress(keyBuilder.build().toString());
		model = tempAddressToAddressModelConverter.convert(addressService.updateAddress(tempAddressModelToAddressConverter.convert(model)));
		
		return model;
	}

	@Override
	public AddressModel getByKey(IKeyBuilder<String> keyBuilder, AddressContext context) {
		Address address = addressService.getAddress(keyBuilder.build().toString());
		AddressModel model =tempAddressToAddressModelConverter.convert(address);
		return model;
	}

	@Override
	public Collection<AddressModel> getCollection(AddressContext context) {
		List<AddressModel> addressModels = new ArrayList<AddressModel>();
		
		for(Address address : addressService.getAll(context)){
		
		addressModels.add(tempAddressToAddressModelConverter.convert(address));
		}
		
		
		
		return addressModels;
	}

@Override
	public AddressModel edit(IKeyBuilder<String> keyBuilder, AddressModel model, AddressContext context) {
		return null;
	}



}
