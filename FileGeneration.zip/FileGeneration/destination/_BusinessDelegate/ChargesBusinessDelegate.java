package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class ChargesBusinessDelegate
		implements IBusinessDelegate<ChargesModel, ChargesContext, IKeyBuilder<String>, String> {

	@Autowired
	private IChargesService chargesService;
	@Autowired
	private ConversionService conversionService;
@Autowired
ChargesModelToChargesConverter tempChargesModelToChargesConverter;
@Autowired
ChargesToChargesModelConverter tempChargesToChargesModelConverter;

	@Override
	@Transactional
	public ChargesModel create(ChargesModel model) {
model = tempChargesToChargesModelConverter.convert(chargesService.create(tempChargesModelToChargesConverter.convert(model)));
		
		return model;
	}
	
	private ChargesModel convertToChargesModel(
			Charges charges) {
		return (ChargesModel) conversionService.convert(
				charges, forObject(charges),
				valueOf(ChargesModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, ChargesContext context) {

	}

	@Override
	public ChargesModel edit(IKeyBuilder<String> keyBuilder, ChargesModel model) {
		Charges charges = chargesService.getCharges(keyBuilder.build().toString());
		model = tempChargesToChargesModelConverter.convert(chargesService.updateCharges(tempChargesModelToChargesConverter.convert(model)));
		
		return model;
	}

	@Override
	public ChargesModel getByKey(IKeyBuilder<String> keyBuilder, ChargesContext context) {
		Charges charges = chargesService.getCharges(keyBuilder.build().toString());
		ChargesModel model =tempChargesToChargesModelConverter.convert(charges);
		return model;
	}

	@Override
	public Collection<ChargesModel> getCollection(ChargesContext context) {
		List<ChargesModel> chargesModels = new ArrayList<ChargesModel>();
		
		for(Charges charges : chargesService.getAll(context)){
		
		chargesModels.add(tempChargesToChargesModelConverter.convert(charges));
		}
		
		
		
		return chargesModels;
	}

@Override
	public ChargesModel edit(IKeyBuilder<String> keyBuilder, ChargesModel model, ChargesContext context) {
		return null;
	}



}
