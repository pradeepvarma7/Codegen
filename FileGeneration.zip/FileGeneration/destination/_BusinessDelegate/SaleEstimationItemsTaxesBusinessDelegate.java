package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class SaleEstimationItemsTaxesBusinessDelegate
		implements IBusinessDelegate<SaleEstimationItemsTaxesModel, SaleEstimationItemsTaxesContext, IKeyBuilder<String>, String> {

	@Autowired
	private ISaleEstimationItemsTaxesService saleEstimationItemsTaxesService;
	@Autowired
	private ConversionService conversionService;
@Autowired
SaleEstimationItemsTaxesModelToSaleEstimationItemsTaxesConverter tempSaleEstimationItemsTaxesModelToSaleEstimationItemsTaxesConverter;
@Autowired
SaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter tempSaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter;

	@Override
	@Transactional
	public SaleEstimationItemsTaxesModel create(SaleEstimationItemsTaxesModel model) {
model = tempSaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter.convert(saleEstimationItemsTaxesService.create(tempSaleEstimationItemsTaxesModelToSaleEstimationItemsTaxesConverter.convert(model)));
		
		return model;
	}
	
	private SaleEstimationItemsTaxesModel convertToSaleEstimationItemsTaxesModel(
			SaleEstimationItemsTaxes saleEstimationItemsTaxes) {
		return (SaleEstimationItemsTaxesModel) conversionService.convert(
				saleEstimationItemsTaxes, forObject(saleEstimationItemsTaxes),
				valueOf(SaleEstimationItemsTaxesModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, SaleEstimationItemsTaxesContext context) {

	}

	@Override
	public SaleEstimationItemsTaxesModel edit(IKeyBuilder<String> keyBuilder, SaleEstimationItemsTaxesModel model) {
		SaleEstimationItemsTaxes saleEstimationItemsTaxes = saleEstimationItemsTaxesService.getSaleEstimationItemsTaxes(keyBuilder.build().toString());
		model = tempSaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter.convert(saleEstimationItemsTaxesService.updateSaleEstimationItemsTaxes(tempSaleEstimationItemsTaxesModelToSaleEstimationItemsTaxesConverter.convert(model)));
		
		return model;
	}

	@Override
	public SaleEstimationItemsTaxesModel getByKey(IKeyBuilder<String> keyBuilder, SaleEstimationItemsTaxesContext context) {
		SaleEstimationItemsTaxes saleEstimationItemsTaxes = saleEstimationItemsTaxesService.getSaleEstimationItemsTaxes(keyBuilder.build().toString());
		SaleEstimationItemsTaxesModel model =tempSaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter.convert(saleEstimationItemsTaxes);
		return model;
	}

	@Override
	public Collection<SaleEstimationItemsTaxesModel> getCollection(SaleEstimationItemsTaxesContext context) {
		List<SaleEstimationItemsTaxesModel> saleEstimationItemsTaxesModels = new ArrayList<SaleEstimationItemsTaxesModel>();
		
		for(SaleEstimationItemsTaxes saleEstimationItemsTaxes : saleEstimationItemsTaxesService.getAll(context)){
		
		saleEstimationItemsTaxesModels.add(tempSaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter.convert(saleEstimationItemsTaxes));
		}
		
		
		
		return saleEstimationItemsTaxesModels;
	}

@Override
	public SaleEstimationItemsTaxesModel edit(IKeyBuilder<String> keyBuilder, SaleEstimationItemsTaxesModel model, SaleEstimationItemsTaxesContext context) {
		return null;
	}



}
