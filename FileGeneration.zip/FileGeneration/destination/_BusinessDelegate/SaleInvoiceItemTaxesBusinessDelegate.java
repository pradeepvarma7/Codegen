package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class SaleInvoiceItemTaxesBusinessDelegate
		implements IBusinessDelegate<SaleInvoiceItemTaxesModel, SaleInvoiceItemTaxesContext, IKeyBuilder<String>, String> {

	@Autowired
	private ISaleInvoiceItemTaxesService saleInvoiceItemTaxesService;
	@Autowired
	private ConversionService conversionService;
@Autowired
SaleInvoiceItemTaxesModelToSaleInvoiceItemTaxesConverter tempSaleInvoiceItemTaxesModelToSaleInvoiceItemTaxesConverter;
@Autowired
SaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter tempSaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter;

	@Override
	@Transactional
	public SaleInvoiceItemTaxesModel create(SaleInvoiceItemTaxesModel model) {
model = tempSaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter.convert(saleInvoiceItemTaxesService.create(tempSaleInvoiceItemTaxesModelToSaleInvoiceItemTaxesConverter.convert(model)));
		
		return model;
	}
	
	private SaleInvoiceItemTaxesModel convertToSaleInvoiceItemTaxesModel(
			SaleInvoiceItemTaxes saleInvoiceItemTaxes) {
		return (SaleInvoiceItemTaxesModel) conversionService.convert(
				saleInvoiceItemTaxes, forObject(saleInvoiceItemTaxes),
				valueOf(SaleInvoiceItemTaxesModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, SaleInvoiceItemTaxesContext context) {

	}

	@Override
	public SaleInvoiceItemTaxesModel edit(IKeyBuilder<String> keyBuilder, SaleInvoiceItemTaxesModel model) {
		SaleInvoiceItemTaxes saleInvoiceItemTaxes = saleInvoiceItemTaxesService.getSaleInvoiceItemTaxes(keyBuilder.build().toString());
		model = tempSaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter.convert(saleInvoiceItemTaxesService.updateSaleInvoiceItemTaxes(tempSaleInvoiceItemTaxesModelToSaleInvoiceItemTaxesConverter.convert(model)));
		
		return model;
	}

	@Override
	public SaleInvoiceItemTaxesModel getByKey(IKeyBuilder<String> keyBuilder, SaleInvoiceItemTaxesContext context) {
		SaleInvoiceItemTaxes saleInvoiceItemTaxes = saleInvoiceItemTaxesService.getSaleInvoiceItemTaxes(keyBuilder.build().toString());
		SaleInvoiceItemTaxesModel model =tempSaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter.convert(saleInvoiceItemTaxes);
		return model;
	}

	@Override
	public Collection<SaleInvoiceItemTaxesModel> getCollection(SaleInvoiceItemTaxesContext context) {
		List<SaleInvoiceItemTaxesModel> saleInvoiceItemTaxesModels = new ArrayList<SaleInvoiceItemTaxesModel>();
		
		for(SaleInvoiceItemTaxes saleInvoiceItemTaxes : saleInvoiceItemTaxesService.getAll(context)){
		
		saleInvoiceItemTaxesModels.add(tempSaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter.convert(saleInvoiceItemTaxes));
		}
		
		
		
		return saleInvoiceItemTaxesModels;
	}

@Override
	public SaleInvoiceItemTaxesModel edit(IKeyBuilder<String> keyBuilder, SaleInvoiceItemTaxesModel model, SaleInvoiceItemTaxesContext context) {
		return null;
	}



}
