package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class OrderChargesBusinessDelegate
		implements IBusinessDelegate<OrderChargesModel, OrderChargesContext, IKeyBuilder<String>, String> {

	@Autowired
	private IOrderChargesService orderChargesService;
	@Autowired
	private ConversionService conversionService;
@Autowired
OrderChargesModelToOrderChargesConverter tempOrderChargesModelToOrderChargesConverter;
@Autowired
OrderChargesToOrderChargesModelConverter tempOrderChargesToOrderChargesModelConverter;

	@Override
	@Transactional
	public OrderChargesModel create(OrderChargesModel model) {
model = tempOrderChargesToOrderChargesModelConverter.convert(orderChargesService.create(tempOrderChargesModelToOrderChargesConverter.convert(model)));
		
		return model;
	}
	
	private OrderChargesModel convertToOrderChargesModel(
			OrderCharges orderCharges) {
		return (OrderChargesModel) conversionService.convert(
				orderCharges, forObject(orderCharges),
				valueOf(OrderChargesModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, OrderChargesContext context) {

	}

	@Override
	public OrderChargesModel edit(IKeyBuilder<String> keyBuilder, OrderChargesModel model) {
		OrderCharges orderCharges = orderChargesService.getOrderCharges(keyBuilder.build().toString());
		model = tempOrderChargesToOrderChargesModelConverter.convert(orderChargesService.updateOrderCharges(tempOrderChargesModelToOrderChargesConverter.convert(model)));
		
		return model;
	}

	@Override
	public OrderChargesModel getByKey(IKeyBuilder<String> keyBuilder, OrderChargesContext context) {
		OrderCharges orderCharges = orderChargesService.getOrderCharges(keyBuilder.build().toString());
		OrderChargesModel model =tempOrderChargesToOrderChargesModelConverter.convert(orderCharges);
		return model;
	}

	@Override
	public Collection<OrderChargesModel> getCollection(OrderChargesContext context) {
		List<OrderChargesModel> orderChargesModels = new ArrayList<OrderChargesModel>();
		
		for(OrderCharges orderCharges : orderChargesService.getAll(context)){
		
		orderChargesModels.add(tempOrderChargesToOrderChargesModelConverter.convert(orderCharges));
		}
		
		
		
		return orderChargesModels;
	}

@Override
	public OrderChargesModel edit(IKeyBuilder<String> keyBuilder, OrderChargesModel model, OrderChargesContext context) {
		return null;
	}



}
