package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class ProductSkuUnitsPriceBusinessDelegate
		implements IBusinessDelegate<ProductSkuUnitsPriceModel, ProductSkuUnitsPriceContext, IKeyBuilder<String>, String> {

	@Autowired
	private IProductSkuUnitsPriceService productSkuUnitsPriceService;
	@Autowired
	private ConversionService conversionService;
@Autowired
ProductSkuUnitsPriceModelToProductSkuUnitsPriceConverter tempProductSkuUnitsPriceModelToProductSkuUnitsPriceConverter;
@Autowired
ProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter tempProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter;

	@Override
	@Transactional
	public ProductSkuUnitsPriceModel create(ProductSkuUnitsPriceModel model) {
model = tempProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter.convert(productSkuUnitsPriceService.create(tempProductSkuUnitsPriceModelToProductSkuUnitsPriceConverter.convert(model)));
		
		return model;
	}
	
	private ProductSkuUnitsPriceModel convertToProductSkuUnitsPriceModel(
			ProductSkuUnitsPrice productSkuUnitsPrice) {
		return (ProductSkuUnitsPriceModel) conversionService.convert(
				productSkuUnitsPrice, forObject(productSkuUnitsPrice),
				valueOf(ProductSkuUnitsPriceModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, ProductSkuUnitsPriceContext context) {

	}

	@Override
	public ProductSkuUnitsPriceModel edit(IKeyBuilder<String> keyBuilder, ProductSkuUnitsPriceModel model) {
		ProductSkuUnitsPrice productSkuUnitsPrice = productSkuUnitsPriceService.getProductSkuUnitsPrice(keyBuilder.build().toString());
		model = tempProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter.convert(productSkuUnitsPriceService.updateProductSkuUnitsPrice(tempProductSkuUnitsPriceModelToProductSkuUnitsPriceConverter.convert(model)));
		
		return model;
	}

	@Override
	public ProductSkuUnitsPriceModel getByKey(IKeyBuilder<String> keyBuilder, ProductSkuUnitsPriceContext context) {
		ProductSkuUnitsPrice productSkuUnitsPrice = productSkuUnitsPriceService.getProductSkuUnitsPrice(keyBuilder.build().toString());
		ProductSkuUnitsPriceModel model =tempProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter.convert(productSkuUnitsPrice);
		return model;
	}

	@Override
	public Collection<ProductSkuUnitsPriceModel> getCollection(ProductSkuUnitsPriceContext context) {
		List<ProductSkuUnitsPriceModel> productSkuUnitsPriceModels = new ArrayList<ProductSkuUnitsPriceModel>();
		
		for(ProductSkuUnitsPrice productSkuUnitsPrice : productSkuUnitsPriceService.getAll(context)){
		
		productSkuUnitsPriceModels.add(tempProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter.convert(productSkuUnitsPrice));
		}
		
		
		
		return productSkuUnitsPriceModels;
	}

@Override
	public ProductSkuUnitsPriceModel edit(IKeyBuilder<String> keyBuilder, ProductSkuUnitsPriceModel model, ProductSkuUnitsPriceContext context) {
		return null;
	}



}
