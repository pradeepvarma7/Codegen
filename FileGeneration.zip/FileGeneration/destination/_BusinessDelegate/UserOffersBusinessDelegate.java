package packageName;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static org.springframework.core.convert.TypeDescriptor.forObject;
import static org.springframework.core.convert.TypeDescriptor.valueOf;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.stereotype.Service;

/*
*@Author varma
*/

@Service

public class UserOffersBusinessDelegate
		implements IBusinessDelegate<UserOffersModel, UserOffersContext, IKeyBuilder<String>, String> {

	@Autowired
	private IUserOffersService userOffersService;
	@Autowired
	private ConversionService conversionService;
@Autowired
UserOffersModelToUserOffersConverter tempUserOffersModelToUserOffersConverter;
@Autowired
UserOffersToUserOffersModelConverter tempUserOffersToUserOffersModelConverter;

	@Override
	@Transactional
	public UserOffersModel create(UserOffersModel model) {
model = tempUserOffersToUserOffersModelConverter.convert(userOffersService.create(tempUserOffersModelToUserOffersConverter.convert(model)));
		
		return model;
	}
	
	private UserOffersModel convertToUserOffersModel(
			UserOffers userOffers) {
		return (UserOffersModel) conversionService.convert(
				userOffers, forObject(userOffers),
				valueOf(UserOffersModel.class));
	}

	@Override
	public void delete(IKeyBuilder<String> keyBuilder, UserOffersContext context) {

	}

	@Override
	public UserOffersModel edit(IKeyBuilder<String> keyBuilder, UserOffersModel model) {
		UserOffers userOffers = userOffersService.getUserOffers(keyBuilder.build().toString());
		model = tempUserOffersToUserOffersModelConverter.convert(userOffersService.updateUserOffers(tempUserOffersModelToUserOffersConverter.convert(model)));
		
		return model;
	}

	@Override
	public UserOffersModel getByKey(IKeyBuilder<String> keyBuilder, UserOffersContext context) {
		UserOffers userOffers = userOffersService.getUserOffers(keyBuilder.build().toString());
		UserOffersModel model =tempUserOffersToUserOffersModelConverter.convert(userOffers);
		return model;
	}

	@Override
	public Collection<UserOffersModel> getCollection(UserOffersContext context) {
		List<UserOffersModel> userOffersModels = new ArrayList<UserOffersModel>();
		
		for(UserOffers userOffers : userOffersService.getAll(context)){
		
		userOffersModels.add(tempUserOffersToUserOffersModelConverter.convert(userOffers));
		}
		
		
		
		return userOffersModels;
	}

@Override
	public UserOffersModel edit(IKeyBuilder<String> keyBuilder, UserOffersModel model, UserOffersContext context) {
		return null;
	}



}
