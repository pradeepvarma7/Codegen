package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.ProductSkuUnitsPrice;
/*
*@Author varma
*/
public interface ProductSkuUnitsPriceRepository extends JpaSpecificationExecutor<ProductSkuUnitsPrice>,PagingAndSortingRepository<ProductSkuUnitsPrice, Serializable>{

}
