package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.OrderCharges;
/*
*@Author varma
*/
public interface OrderChargesRepository extends JpaSpecificationExecutor<OrderCharges>,PagingAndSortingRepository<OrderCharges, Serializable>{

}
