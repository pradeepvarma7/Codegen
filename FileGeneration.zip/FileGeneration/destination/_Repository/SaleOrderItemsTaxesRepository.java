package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.SaleOrderItemsTaxes;
/*
*@Author varma
*/
public interface SaleOrderItemsTaxesRepository extends JpaSpecificationExecutor<SaleOrderItemsTaxes>,PagingAndSortingRepository<SaleOrderItemsTaxes, Serializable>{

}
