package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.OrderDeliveryAddress;
/*
*@Author varma
*/
public interface OrderDeliveryAddressRepository extends JpaSpecificationExecutor<OrderDeliveryAddress>,PagingAndSortingRepository<OrderDeliveryAddress, Serializable>{

}
