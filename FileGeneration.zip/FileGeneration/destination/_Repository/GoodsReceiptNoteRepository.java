package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.GoodsReceiptNote;
/*
*@Author varma
*/
public interface GoodsReceiptNoteRepository extends JpaSpecificationExecutor<GoodsReceiptNote>,PagingAndSortingRepository<GoodsReceiptNote, Serializable>{

}
