package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.GrnTaxes;
/*
*@Author varma
*/
public interface GrnTaxesRepository extends JpaSpecificationExecutor<GrnTaxes>,PagingAndSortingRepository<GrnTaxes, Serializable>{

}
