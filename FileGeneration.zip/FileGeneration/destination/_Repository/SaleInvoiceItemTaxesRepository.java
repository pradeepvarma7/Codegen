package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.SaleInvoiceItemTaxes;
/*
*@Author varma
*/
public interface SaleInvoiceItemTaxesRepository extends JpaSpecificationExecutor<SaleInvoiceItemTaxes>,PagingAndSortingRepository<SaleInvoiceItemTaxes, Serializable>{

}
