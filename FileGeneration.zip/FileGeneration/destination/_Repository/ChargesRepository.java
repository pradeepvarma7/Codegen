package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.Charges;
/*
*@Author varma
*/
public interface ChargesRepository extends JpaSpecificationExecutor<Charges>,PagingAndSortingRepository<Charges, Serializable>{

}
