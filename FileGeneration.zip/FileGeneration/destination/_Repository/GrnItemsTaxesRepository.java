package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.GrnItemsTaxes;
/*
*@Author varma
*/
public interface GrnItemsTaxesRepository extends JpaSpecificationExecutor<GrnItemsTaxes>,PagingAndSortingRepository<GrnItemsTaxes, Serializable>{

}
