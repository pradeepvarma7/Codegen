package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.GrnItems;
/*
*@Author varma
*/
public interface GrnItemsRepository extends JpaSpecificationExecutor<GrnItems>,PagingAndSortingRepository<GrnItems, Serializable>{

}
