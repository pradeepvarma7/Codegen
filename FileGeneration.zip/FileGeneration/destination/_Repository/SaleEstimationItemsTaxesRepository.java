package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.SaleEstimationItemsTaxes;
/*
*@Author varma
*/
public interface SaleEstimationItemsTaxesRepository extends JpaSpecificationExecutor<SaleEstimationItemsTaxes>,PagingAndSortingRepository<SaleEstimationItemsTaxes, Serializable>{

}
