package packageName;

import java.io.Serializable;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.payitezy.domain.Address;
/*
*@Author varma
*/
public interface AddressRepository extends JpaSpecificationExecutor<Address>,PagingAndSortingRepository<Address, Serializable>{

}
