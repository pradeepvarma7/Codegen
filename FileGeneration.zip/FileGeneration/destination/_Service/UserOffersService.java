package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.UserOffersRepository;
import com.payitezy.domain.UserOffers;
/*
*@Author varma
*/
@Component
public class UserOffersService implements IUserOffersService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private UserOffersRepository userOffersRepository;
	@Override
	public UserOffers create(UserOffers userOffers) {
		
		return userOffersRepository.save(userOffers);
	}

	@Override
	public void deleteUserOffers(String userOffersId) {
		
		
	}

	@Override
	public UserOffers getUserOffers(String userOffersId) {
		
		 return userOffersRepository.findById(userOffersId).orElse(null);
	}

	@Override
	public List<UserOffers> getAll(UserOffersContext context) {
	List<UserOffers> userOffers= (List<UserOffers>)userOffersRepository.findAll();

		return userOffers;
	}

	@Override
	public UserOffers updateUserOffers(UserOffers userOffers) {
UserOffers userOfferss = getUserOffers(userOffers
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(userOfferss, userOffers);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return userOffersRepository.save(userOfferss);
	}

}
