package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.PromotionsRepository;
import com.payitezy.domain.Promotions;
/*
*@Author varma
*/
@Component
public class PromotionsService implements IPromotionsService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private PromotionsRepository promotionsRepository;
	@Override
	public Promotions create(Promotions promotions) {
		
		return promotionsRepository.save(promotions);
	}

	@Override
	public void deletePromotions(String promotionsId) {
		
		
	}

	@Override
	public Promotions getPromotions(String promotionsId) {
		
		 return promotionsRepository.findById(promotionsId).orElse(null);
	}

	@Override
	public List<Promotions> getAll(PromotionsContext context) {
	List<Promotions> promotions= (List<Promotions>)promotionsRepository.findAll();

		return promotions;
	}

	@Override
	public Promotions updatePromotions(Promotions promotions) {
Promotions promotionss = getPromotions(promotions
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(promotionss, promotions);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return promotionsRepository.save(promotionss);
	}

}
