package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.GrnTaxesRepository;
import com.payitezy.domain.GrnTaxes;
/*
*@Author varma
*/
@Component
public class GrnTaxesService implements IGrnTaxesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private GrnTaxesRepository grnTaxesRepository;
	@Override
	public GrnTaxes create(GrnTaxes grnTaxes) {
		
		return grnTaxesRepository.save(grnTaxes);
	}

	@Override
	public void deleteGrnTaxes(String grnTaxesId) {
		
		
	}

	@Override
	public GrnTaxes getGrnTaxes(String grnTaxesId) {
		
		 return grnTaxesRepository.findById(grnTaxesId).orElse(null);
	}

	@Override
	public List<GrnTaxes> getAll(GrnTaxesContext context) {
	List<GrnTaxes> grnTaxes= (List<GrnTaxes>)grnTaxesRepository.findAll();

		return grnTaxes;
	}

	@Override
	public GrnTaxes updateGrnTaxes(GrnTaxes grnTaxes) {
GrnTaxes grnTaxess = getGrnTaxes(grnTaxes
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(grnTaxess, grnTaxes);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return grnTaxesRepository.save(grnTaxess);
	}

}
