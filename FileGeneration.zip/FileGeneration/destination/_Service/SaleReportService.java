package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.SaleReportRepository;
import com.payitezy.domain.SaleReport;
/*
*@Author varma
*/
@Component
public class SaleReportService implements ISaleReportService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private SaleReportRepository saleReportRepository;
	@Override
	public SaleReport create(SaleReport saleReport) {
		
		return saleReportRepository.save(saleReport);
	}

	@Override
	public void deleteSaleReport(String saleReportId) {
		
		
	}

	@Override
	public SaleReport getSaleReport(String saleReportId) {
		
		 return saleReportRepository.findById(saleReportId).orElse(null);
	}

	@Override
	public List<SaleReport> getAll(SaleReportContext context) {
	List<SaleReport> saleReport= (List<SaleReport>)saleReportRepository.findAll();

		return saleReport;
	}

	@Override
	public SaleReport updateSaleReport(SaleReport saleReport) {
SaleReport saleReports = getSaleReport(saleReport
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(saleReports, saleReport);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return saleReportRepository.save(saleReports);
	}

}
