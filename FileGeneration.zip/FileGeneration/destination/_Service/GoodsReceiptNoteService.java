package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.GoodsReceiptNoteRepository;
import com.payitezy.domain.GoodsReceiptNote;
/*
*@Author varma
*/
@Component
public class GoodsReceiptNoteService implements IGoodsReceiptNoteService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private GoodsReceiptNoteRepository goodsReceiptNoteRepository;
	@Override
	public GoodsReceiptNote create(GoodsReceiptNote goodsReceiptNote) {
		
		return goodsReceiptNoteRepository.save(goodsReceiptNote);
	}

	@Override
	public void deleteGoodsReceiptNote(String goodsReceiptNoteId) {
		
		
	}

	@Override
	public GoodsReceiptNote getGoodsReceiptNote(String goodsReceiptNoteId) {
		
		 return goodsReceiptNoteRepository.findById(goodsReceiptNoteId).orElse(null);
	}

	@Override
	public List<GoodsReceiptNote> getAll(GoodsReceiptNoteContext context) {
	List<GoodsReceiptNote> goodsReceiptNote= (List<GoodsReceiptNote>)goodsReceiptNoteRepository.findAll();

		return goodsReceiptNote;
	}

	@Override
	public GoodsReceiptNote updateGoodsReceiptNote(GoodsReceiptNote goodsReceiptNote) {
GoodsReceiptNote goodsReceiptNotes = getGoodsReceiptNote(goodsReceiptNote
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(goodsReceiptNotes, goodsReceiptNote);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return goodsReceiptNoteRepository.save(goodsReceiptNotes);
	}

}
