package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.SaleInvoiceItemTaxesRepository;
import com.payitezy.domain.SaleInvoiceItemTaxes;
/*
*@Author varma
*/
@Component
public class SaleInvoiceItemTaxesService implements ISaleInvoiceItemTaxesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private SaleInvoiceItemTaxesRepository saleInvoiceItemTaxesRepository;
	@Override
	public SaleInvoiceItemTaxes create(SaleInvoiceItemTaxes saleInvoiceItemTaxes) {
		
		return saleInvoiceItemTaxesRepository.save(saleInvoiceItemTaxes);
	}

	@Override
	public void deleteSaleInvoiceItemTaxes(String saleInvoiceItemTaxesId) {
		
		
	}

	@Override
	public SaleInvoiceItemTaxes getSaleInvoiceItemTaxes(String saleInvoiceItemTaxesId) {
		
		 return saleInvoiceItemTaxesRepository.findById(saleInvoiceItemTaxesId).orElse(null);
	}

	@Override
	public List<SaleInvoiceItemTaxes> getAll(SaleInvoiceItemTaxesContext context) {
	List<SaleInvoiceItemTaxes> saleInvoiceItemTaxes= (List<SaleInvoiceItemTaxes>)saleInvoiceItemTaxesRepository.findAll();

		return saleInvoiceItemTaxes;
	}

	@Override
	public SaleInvoiceItemTaxes updateSaleInvoiceItemTaxes(SaleInvoiceItemTaxes saleInvoiceItemTaxes) {
SaleInvoiceItemTaxes saleInvoiceItemTaxess = getSaleInvoiceItemTaxes(saleInvoiceItemTaxes
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(saleInvoiceItemTaxess, saleInvoiceItemTaxes);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return saleInvoiceItemTaxesRepository.save(saleInvoiceItemTaxess);
	}

}
