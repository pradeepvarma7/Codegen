package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.SaleEstimationItemsTaxesRepository;
import com.payitezy.domain.SaleEstimationItemsTaxes;
/*
*@Author varma
*/
@Component
public class SaleEstimationItemsTaxesService implements ISaleEstimationItemsTaxesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private SaleEstimationItemsTaxesRepository saleEstimationItemsTaxesRepository;
	@Override
	public SaleEstimationItemsTaxes create(SaleEstimationItemsTaxes saleEstimationItemsTaxes) {
		
		return saleEstimationItemsTaxesRepository.save(saleEstimationItemsTaxes);
	}

	@Override
	public void deleteSaleEstimationItemsTaxes(String saleEstimationItemsTaxesId) {
		
		
	}

	@Override
	public SaleEstimationItemsTaxes getSaleEstimationItemsTaxes(String saleEstimationItemsTaxesId) {
		
		 return saleEstimationItemsTaxesRepository.findById(saleEstimationItemsTaxesId).orElse(null);
	}

	@Override
	public List<SaleEstimationItemsTaxes> getAll(SaleEstimationItemsTaxesContext context) {
	List<SaleEstimationItemsTaxes> saleEstimationItemsTaxes= (List<SaleEstimationItemsTaxes>)saleEstimationItemsTaxesRepository.findAll();

		return saleEstimationItemsTaxes;
	}

	@Override
	public SaleEstimationItemsTaxes updateSaleEstimationItemsTaxes(SaleEstimationItemsTaxes saleEstimationItemsTaxes) {
SaleEstimationItemsTaxes saleEstimationItemsTaxess = getSaleEstimationItemsTaxes(saleEstimationItemsTaxes
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(saleEstimationItemsTaxess, saleEstimationItemsTaxes);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return saleEstimationItemsTaxesRepository.save(saleEstimationItemsTaxess);
	}

}
