package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.BranchOrderRepository;
import com.payitezy.domain.BranchOrder;
/*
*@Author varma
*/
@Component
public class BranchOrderService implements IBranchOrderService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private BranchOrderRepository branchOrderRepository;
	@Override
	public BranchOrder create(BranchOrder branchOrder) {
		
		return branchOrderRepository.save(branchOrder);
	}

	@Override
	public void deleteBranchOrder(String branchOrderId) {
		
		
	}

	@Override
	public BranchOrder getBranchOrder(String branchOrderId) {
		
		 return branchOrderRepository.findById(branchOrderId).orElse(null);
	}

	@Override
	public List<BranchOrder> getAll(BranchOrderContext context) {
	List<BranchOrder> branchOrder= (List<BranchOrder>)branchOrderRepository.findAll();

		return branchOrder;
	}

	@Override
	public BranchOrder updateBranchOrder(BranchOrder branchOrder) {
BranchOrder branchOrders = getBranchOrder(branchOrder
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(branchOrders, branchOrder);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return branchOrderRepository.save(branchOrders);
	}

}
