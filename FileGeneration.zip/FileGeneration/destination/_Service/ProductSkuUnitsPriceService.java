package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.ProductSkuUnitsPriceRepository;
import com.payitezy.domain.ProductSkuUnitsPrice;
/*
*@Author varma
*/
@Component
public class ProductSkuUnitsPriceService implements IProductSkuUnitsPriceService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private ProductSkuUnitsPriceRepository productSkuUnitsPriceRepository;
	@Override
	public ProductSkuUnitsPrice create(ProductSkuUnitsPrice productSkuUnitsPrice) {
		
		return productSkuUnitsPriceRepository.save(productSkuUnitsPrice);
	}

	@Override
	public void deleteProductSkuUnitsPrice(String productSkuUnitsPriceId) {
		
		
	}

	@Override
	public ProductSkuUnitsPrice getProductSkuUnitsPrice(String productSkuUnitsPriceId) {
		
		 return productSkuUnitsPriceRepository.findById(productSkuUnitsPriceId).orElse(null);
	}

	@Override
	public List<ProductSkuUnitsPrice> getAll(ProductSkuUnitsPriceContext context) {
	List<ProductSkuUnitsPrice> productSkuUnitsPrice= (List<ProductSkuUnitsPrice>)productSkuUnitsPriceRepository.findAll();

		return productSkuUnitsPrice;
	}

	@Override
	public ProductSkuUnitsPrice updateProductSkuUnitsPrice(ProductSkuUnitsPrice productSkuUnitsPrice) {
ProductSkuUnitsPrice productSkuUnitsPrices = getProductSkuUnitsPrice(productSkuUnitsPrice
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(productSkuUnitsPrices, productSkuUnitsPrice);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return productSkuUnitsPriceRepository.save(productSkuUnitsPrices);
	}

}
