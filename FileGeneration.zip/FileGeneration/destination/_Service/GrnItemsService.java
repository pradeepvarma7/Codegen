package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.GrnItemsRepository;
import com.payitezy.domain.GrnItems;
/*
*@Author varma
*/
@Component
public class GrnItemsService implements IGrnItemsService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private GrnItemsRepository grnItemsRepository;
	@Override
	public GrnItems create(GrnItems grnItems) {
		
		return grnItemsRepository.save(grnItems);
	}

	@Override
	public void deleteGrnItems(String grnItemsId) {
		
		
	}

	@Override
	public GrnItems getGrnItems(String grnItemsId) {
		
		 return grnItemsRepository.findById(grnItemsId).orElse(null);
	}

	@Override
	public List<GrnItems> getAll(GrnItemsContext context) {
	List<GrnItems> grnItems= (List<GrnItems>)grnItemsRepository.findAll();

		return grnItems;
	}

	@Override
	public GrnItems updateGrnItems(GrnItems grnItems) {
GrnItems grnItemss = getGrnItems(grnItems
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(grnItemss, grnItems);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return grnItemsRepository.save(grnItemss);
	}

}
