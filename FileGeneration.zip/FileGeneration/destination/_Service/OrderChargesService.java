package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.OrderChargesRepository;
import com.payitezy.domain.OrderCharges;
/*
*@Author varma
*/
@Component
public class OrderChargesService implements IOrderChargesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private OrderChargesRepository orderChargesRepository;
	@Override
	public OrderCharges create(OrderCharges orderCharges) {
		
		return orderChargesRepository.save(orderCharges);
	}

	@Override
	public void deleteOrderCharges(String orderChargesId) {
		
		
	}

	@Override
	public OrderCharges getOrderCharges(String orderChargesId) {
		
		 return orderChargesRepository.findById(orderChargesId).orElse(null);
	}

	@Override
	public List<OrderCharges> getAll(OrderChargesContext context) {
	List<OrderCharges> orderCharges= (List<OrderCharges>)orderChargesRepository.findAll();

		return orderCharges;
	}

	@Override
	public OrderCharges updateOrderCharges(OrderCharges orderCharges) {
OrderCharges orderChargess = getOrderCharges(orderCharges
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(orderChargess, orderCharges);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return orderChargesRepository.save(orderChargess);
	}

}
