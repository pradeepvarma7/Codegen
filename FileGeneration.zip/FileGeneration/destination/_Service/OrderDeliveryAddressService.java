package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.OrderDeliveryAddressRepository;
import com.payitezy.domain.OrderDeliveryAddress;
/*
*@Author varma
*/
@Component
public class OrderDeliveryAddressService implements IOrderDeliveryAddressService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private OrderDeliveryAddressRepository orderDeliveryAddressRepository;
	@Override
	public OrderDeliveryAddress create(OrderDeliveryAddress orderDeliveryAddress) {
		
		return orderDeliveryAddressRepository.save(orderDeliveryAddress);
	}

	@Override
	public void deleteOrderDeliveryAddress(String orderDeliveryAddressId) {
		
		
	}

	@Override
	public OrderDeliveryAddress getOrderDeliveryAddress(String orderDeliveryAddressId) {
		
		 return orderDeliveryAddressRepository.findById(orderDeliveryAddressId).orElse(null);
	}

	@Override
	public List<OrderDeliveryAddress> getAll(OrderDeliveryAddressContext context) {
	List<OrderDeliveryAddress> orderDeliveryAddress= (List<OrderDeliveryAddress>)orderDeliveryAddressRepository.findAll();

		return orderDeliveryAddress;
	}

	@Override
	public OrderDeliveryAddress updateOrderDeliveryAddress(OrderDeliveryAddress orderDeliveryAddress) {
OrderDeliveryAddress orderDeliveryAddresss = getOrderDeliveryAddress(orderDeliveryAddress
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(orderDeliveryAddresss, orderDeliveryAddress);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return orderDeliveryAddressRepository.save(orderDeliveryAddresss);
	}

}
