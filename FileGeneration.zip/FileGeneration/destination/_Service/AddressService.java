package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.AddressRepository;
import com.payitezy.domain.Address;
/*
*@Author varma
*/
@Component
public class AddressService implements IAddressService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private AddressRepository addressRepository;
	@Override
	public Address create(Address address) {
		
		return addressRepository.save(address);
	}

	@Override
	public void deleteAddress(String addressId) {
		
		
	}

	@Override
	public Address getAddress(String addressId) {
		
		 return addressRepository.findById(addressId).orElse(null);
	}

	@Override
	public List<Address> getAll(AddressContext context) {
	List<Address> address= (List<Address>)addressRepository.findAll();

		return address;
	}

	@Override
	public Address updateAddress(Address address) {
Address addresss = getAddress(address
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(addresss, address);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return addressRepository.save(addresss);
	}

}
