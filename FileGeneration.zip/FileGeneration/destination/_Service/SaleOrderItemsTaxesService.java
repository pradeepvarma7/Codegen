package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.SaleOrderItemsTaxesRepository;
import com.payitezy.domain.SaleOrderItemsTaxes;
/*
*@Author varma
*/
@Component
public class SaleOrderItemsTaxesService implements ISaleOrderItemsTaxesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private SaleOrderItemsTaxesRepository saleOrderItemsTaxesRepository;
	@Override
	public SaleOrderItemsTaxes create(SaleOrderItemsTaxes saleOrderItemsTaxes) {
		
		return saleOrderItemsTaxesRepository.save(saleOrderItemsTaxes);
	}

	@Override
	public void deleteSaleOrderItemsTaxes(String saleOrderItemsTaxesId) {
		
		
	}

	@Override
	public SaleOrderItemsTaxes getSaleOrderItemsTaxes(String saleOrderItemsTaxesId) {
		
		 return saleOrderItemsTaxesRepository.findById(saleOrderItemsTaxesId).orElse(null);
	}

	@Override
	public List<SaleOrderItemsTaxes> getAll(SaleOrderItemsTaxesContext context) {
	List<SaleOrderItemsTaxes> saleOrderItemsTaxes= (List<SaleOrderItemsTaxes>)saleOrderItemsTaxesRepository.findAll();

		return saleOrderItemsTaxes;
	}

	@Override
	public SaleOrderItemsTaxes updateSaleOrderItemsTaxes(SaleOrderItemsTaxes saleOrderItemsTaxes) {
SaleOrderItemsTaxes saleOrderItemsTaxess = getSaleOrderItemsTaxes(saleOrderItemsTaxes
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(saleOrderItemsTaxess, saleOrderItemsTaxes);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return saleOrderItemsTaxesRepository.save(saleOrderItemsTaxess);
	}

}
