package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.ChargesRepository;
import com.payitezy.domain.Charges;
/*
*@Author varma
*/
@Component
public class ChargesService implements IChargesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private ChargesRepository chargesRepository;
	@Override
	public Charges create(Charges charges) {
		
		return chargesRepository.save(charges);
	}

	@Override
	public void deleteCharges(String chargesId) {
		
		
	}

	@Override
	public Charges getCharges(String chargesId) {
		
		 return chargesRepository.findById(chargesId).orElse(null);
	}

	@Override
	public List<Charges> getAll(ChargesContext context) {
	List<Charges> charges= (List<Charges>)chargesRepository.findAll();

		return charges;
	}

	@Override
	public Charges updateCharges(Charges charges) {
Charges chargess = getCharges(charges
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(chargess, charges);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return chargesRepository.save(chargess);
	}

}
