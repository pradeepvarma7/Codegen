package packageName;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.payitezy.dao.GrnItemsTaxesRepository;
import com.payitezy.domain.GrnItemsTaxes;
/*
*@Author varma
*/
@Component
public class GrnItemsTaxesService implements IGrnItemsTaxesService{
	@Autowired
	private NullAwareBeanUtilsBean nonNullBeanUtiles;

	@Autowired
	private GrnItemsTaxesRepository grnItemsTaxesRepository;
	@Override
	public GrnItemsTaxes create(GrnItemsTaxes grnItemsTaxes) {
		
		return grnItemsTaxesRepository.save(grnItemsTaxes);
	}

	@Override
	public void deleteGrnItemsTaxes(String grnItemsTaxesId) {
		
		
	}

	@Override
	public GrnItemsTaxes getGrnItemsTaxes(String grnItemsTaxesId) {
		
		 return grnItemsTaxesRepository.findById(grnItemsTaxesId).orElse(null);
	}

	@Override
	public List<GrnItemsTaxes> getAll(GrnItemsTaxesContext context) {
	List<GrnItemsTaxes> grnItemsTaxes= (List<GrnItemsTaxes>)grnItemsTaxesRepository.findAll();

		return grnItemsTaxes;
	}

	@Override
	public GrnItemsTaxes updateGrnItemsTaxes(GrnItemsTaxes grnItemsTaxes) {
GrnItemsTaxes grnItemsTaxess = getGrnItemsTaxes(grnItemsTaxes
				.getId());
		try {
			nonNullBeanUtiles.copyProperties(grnItemsTaxess, grnItemsTaxes);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}

	return grnItemsTaxesRepository.save(grnItemsTaxess);
	}

}
