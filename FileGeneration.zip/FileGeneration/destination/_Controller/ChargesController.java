package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/charges", produces = "application/json", consumes = "application/json")
public class ChargesController {

	private IBusinessDelegate<ChargesModel, ChargesContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<ChargesContext> chargesContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<ChargesModel> createCharges(@RequestBody  ChargesModel chargesModel) {
	chargesModel =	businessDelegate.create(chargesModel);
		return new ResponseEntity<ChargesModel>(chargesModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<ChargesModel> edit(@PathVariable(value = "id") final String chargesId,
			@RequestBody  ChargesModel chargesModel) {

	chargesModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(chargesId), chargesModel);
		return new ResponseEntity<ChargesModel>(chargesModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<ChargesModel>> getAll() {
		ChargesContext chargesContext = chargesContextFactory.getObject();
		Collection<ChargesModel> chargesModels = businessDelegate.getCollection(chargesContext);
		
		return new ResponseEntity<Collection<ChargesModel>>(chargesModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<ChargesModel> getCharges(@PathVariable(value = "id") final String chargesId) {
		ChargesContext chargesContext = chargesContextFactory.getObject();

		ChargesModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(chargesId),
				chargesContext);
		return new ResponseEntity<ChargesModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "chargesBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<ChargesModel, ChargesContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setChargesObjectFactory(final ObjectFactory<ChargesContext> chargesContextFactory) {
		this.chargesContextFactory = chargesContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
