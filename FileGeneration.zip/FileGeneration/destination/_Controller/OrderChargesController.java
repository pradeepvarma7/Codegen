package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/orderCharges", produces = "application/json", consumes = "application/json")
public class OrderChargesController {

	private IBusinessDelegate<OrderChargesModel, OrderChargesContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<OrderChargesContext> orderChargesContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<OrderChargesModel> createOrderCharges(@RequestBody  OrderChargesModel orderChargesModel) {
	orderChargesModel =	businessDelegate.create(orderChargesModel);
		return new ResponseEntity<OrderChargesModel>(orderChargesModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<OrderChargesModel> edit(@PathVariable(value = "id") final String orderChargesId,
			@RequestBody  OrderChargesModel orderChargesModel) {

	orderChargesModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(orderChargesId), orderChargesModel);
		return new ResponseEntity<OrderChargesModel>(orderChargesModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<OrderChargesModel>> getAll() {
		OrderChargesContext orderChargesContext = orderChargesContextFactory.getObject();
		Collection<OrderChargesModel> orderChargesModels = businessDelegate.getCollection(orderChargesContext);
		
		return new ResponseEntity<Collection<OrderChargesModel>>(orderChargesModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<OrderChargesModel> getOrderCharges(@PathVariable(value = "id") final String orderChargesId) {
		OrderChargesContext orderChargesContext = orderChargesContextFactory.getObject();

		OrderChargesModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(orderChargesId),
				orderChargesContext);
		return new ResponseEntity<OrderChargesModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "orderChargesBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<OrderChargesModel, OrderChargesContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setOrderChargesObjectFactory(final ObjectFactory<OrderChargesContext> orderChargesContextFactory) {
		this.orderChargesContextFactory = orderChargesContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
