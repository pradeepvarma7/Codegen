package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/grnItems", produces = "application/json", consumes = "application/json")
public class GrnItemsController {

	private IBusinessDelegate<GrnItemsModel, GrnItemsContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<GrnItemsContext> grnItemsContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<GrnItemsModel> createGrnItems(@RequestBody  GrnItemsModel grnItemsModel) {
	grnItemsModel =	businessDelegate.create(grnItemsModel);
		return new ResponseEntity<GrnItemsModel>(grnItemsModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<GrnItemsModel> edit(@PathVariable(value = "id") final String grnItemsId,
			@RequestBody  GrnItemsModel grnItemsModel) {

	grnItemsModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(grnItemsId), grnItemsModel);
		return new ResponseEntity<GrnItemsModel>(grnItemsModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<GrnItemsModel>> getAll() {
		GrnItemsContext grnItemsContext = grnItemsContextFactory.getObject();
		Collection<GrnItemsModel> grnItemsModels = businessDelegate.getCollection(grnItemsContext);
		
		return new ResponseEntity<Collection<GrnItemsModel>>(grnItemsModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<GrnItemsModel> getGrnItems(@PathVariable(value = "id") final String grnItemsId) {
		GrnItemsContext grnItemsContext = grnItemsContextFactory.getObject();

		GrnItemsModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(grnItemsId),
				grnItemsContext);
		return new ResponseEntity<GrnItemsModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "grnItemsBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<GrnItemsModel, GrnItemsContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setGrnItemsObjectFactory(final ObjectFactory<GrnItemsContext> grnItemsContextFactory) {
		this.grnItemsContextFactory = grnItemsContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
