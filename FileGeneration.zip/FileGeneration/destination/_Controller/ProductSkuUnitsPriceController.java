package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/productSkuUnitsPrice", produces = "application/json", consumes = "application/json")
public class ProductSkuUnitsPriceController {

	private IBusinessDelegate<ProductSkuUnitsPriceModel, ProductSkuUnitsPriceContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<ProductSkuUnitsPriceContext> productSkuUnitsPriceContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<ProductSkuUnitsPriceModel> createProductSkuUnitsPrice(@RequestBody  ProductSkuUnitsPriceModel productSkuUnitsPriceModel) {
	productSkuUnitsPriceModel =	businessDelegate.create(productSkuUnitsPriceModel);
		return new ResponseEntity<ProductSkuUnitsPriceModel>(productSkuUnitsPriceModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<ProductSkuUnitsPriceModel> edit(@PathVariable(value = "id") final String productSkuUnitsPriceId,
			@RequestBody  ProductSkuUnitsPriceModel productSkuUnitsPriceModel) {

	productSkuUnitsPriceModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(productSkuUnitsPriceId), productSkuUnitsPriceModel);
		return new ResponseEntity<ProductSkuUnitsPriceModel>(productSkuUnitsPriceModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<ProductSkuUnitsPriceModel>> getAll() {
		ProductSkuUnitsPriceContext productSkuUnitsPriceContext = productSkuUnitsPriceContextFactory.getObject();
		Collection<ProductSkuUnitsPriceModel> productSkuUnitsPriceModels = businessDelegate.getCollection(productSkuUnitsPriceContext);
		
		return new ResponseEntity<Collection<ProductSkuUnitsPriceModel>>(productSkuUnitsPriceModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<ProductSkuUnitsPriceModel> getProductSkuUnitsPrice(@PathVariable(value = "id") final String productSkuUnitsPriceId) {
		ProductSkuUnitsPriceContext productSkuUnitsPriceContext = productSkuUnitsPriceContextFactory.getObject();

		ProductSkuUnitsPriceModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(productSkuUnitsPriceId),
				productSkuUnitsPriceContext);
		return new ResponseEntity<ProductSkuUnitsPriceModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "productSkuUnitsPriceBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<ProductSkuUnitsPriceModel, ProductSkuUnitsPriceContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setProductSkuUnitsPriceObjectFactory(final ObjectFactory<ProductSkuUnitsPriceContext> productSkuUnitsPriceContextFactory) {
		this.productSkuUnitsPriceContextFactory = productSkuUnitsPriceContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
