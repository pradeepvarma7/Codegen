package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/grnTaxes", produces = "application/json", consumes = "application/json")
public class GrnTaxesController {

	private IBusinessDelegate<GrnTaxesModel, GrnTaxesContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<GrnTaxesContext> grnTaxesContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<GrnTaxesModel> createGrnTaxes(@RequestBody  GrnTaxesModel grnTaxesModel) {
	grnTaxesModel =	businessDelegate.create(grnTaxesModel);
		return new ResponseEntity<GrnTaxesModel>(grnTaxesModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<GrnTaxesModel> edit(@PathVariable(value = "id") final String grnTaxesId,
			@RequestBody  GrnTaxesModel grnTaxesModel) {

	grnTaxesModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(grnTaxesId), grnTaxesModel);
		return new ResponseEntity<GrnTaxesModel>(grnTaxesModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<GrnTaxesModel>> getAll() {
		GrnTaxesContext grnTaxesContext = grnTaxesContextFactory.getObject();
		Collection<GrnTaxesModel> grnTaxesModels = businessDelegate.getCollection(grnTaxesContext);
		
		return new ResponseEntity<Collection<GrnTaxesModel>>(grnTaxesModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<GrnTaxesModel> getGrnTaxes(@PathVariable(value = "id") final String grnTaxesId) {
		GrnTaxesContext grnTaxesContext = grnTaxesContextFactory.getObject();

		GrnTaxesModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(grnTaxesId),
				grnTaxesContext);
		return new ResponseEntity<GrnTaxesModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "grnTaxesBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<GrnTaxesModel, GrnTaxesContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setGrnTaxesObjectFactory(final ObjectFactory<GrnTaxesContext> grnTaxesContextFactory) {
		this.grnTaxesContextFactory = grnTaxesContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
