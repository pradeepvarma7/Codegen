package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/branchOrder", produces = "application/json", consumes = "application/json")
public class BranchOrderController {

	private IBusinessDelegate<BranchOrderModel, BranchOrderContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<BranchOrderContext> branchOrderContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<BranchOrderModel> createBranchOrder(@RequestBody  BranchOrderModel branchOrderModel) {
	branchOrderModel =	businessDelegate.create(branchOrderModel);
		return new ResponseEntity<BranchOrderModel>(branchOrderModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<BranchOrderModel> edit(@PathVariable(value = "id") final String branchOrderId,
			@RequestBody  BranchOrderModel branchOrderModel) {

	branchOrderModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(branchOrderId), branchOrderModel);
		return new ResponseEntity<BranchOrderModel>(branchOrderModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<BranchOrderModel>> getAll() {
		BranchOrderContext branchOrderContext = branchOrderContextFactory.getObject();
		Collection<BranchOrderModel> branchOrderModels = businessDelegate.getCollection(branchOrderContext);
		
		return new ResponseEntity<Collection<BranchOrderModel>>(branchOrderModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<BranchOrderModel> getBranchOrder(@PathVariable(value = "id") final String branchOrderId) {
		BranchOrderContext branchOrderContext = branchOrderContextFactory.getObject();

		BranchOrderModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(branchOrderId),
				branchOrderContext);
		return new ResponseEntity<BranchOrderModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "branchOrderBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<BranchOrderModel, BranchOrderContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setBranchOrderObjectFactory(final ObjectFactory<BranchOrderContext> branchOrderContextFactory) {
		this.branchOrderContextFactory = branchOrderContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
