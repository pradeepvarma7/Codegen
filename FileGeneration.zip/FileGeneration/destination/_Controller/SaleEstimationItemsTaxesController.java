package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/saleEstimationItemsTaxes", produces = "application/json", consumes = "application/json")
public class SaleEstimationItemsTaxesController {

	private IBusinessDelegate<SaleEstimationItemsTaxesModel, SaleEstimationItemsTaxesContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<SaleEstimationItemsTaxesContext> saleEstimationItemsTaxesContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<SaleEstimationItemsTaxesModel> createSaleEstimationItemsTaxes(@RequestBody  SaleEstimationItemsTaxesModel saleEstimationItemsTaxesModel) {
	saleEstimationItemsTaxesModel =	businessDelegate.create(saleEstimationItemsTaxesModel);
		return new ResponseEntity<SaleEstimationItemsTaxesModel>(saleEstimationItemsTaxesModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<SaleEstimationItemsTaxesModel> edit(@PathVariable(value = "id") final String saleEstimationItemsTaxesId,
			@RequestBody  SaleEstimationItemsTaxesModel saleEstimationItemsTaxesModel) {

	saleEstimationItemsTaxesModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(saleEstimationItemsTaxesId), saleEstimationItemsTaxesModel);
		return new ResponseEntity<SaleEstimationItemsTaxesModel>(saleEstimationItemsTaxesModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<SaleEstimationItemsTaxesModel>> getAll() {
		SaleEstimationItemsTaxesContext saleEstimationItemsTaxesContext = saleEstimationItemsTaxesContextFactory.getObject();
		Collection<SaleEstimationItemsTaxesModel> saleEstimationItemsTaxesModels = businessDelegate.getCollection(saleEstimationItemsTaxesContext);
		
		return new ResponseEntity<Collection<SaleEstimationItemsTaxesModel>>(saleEstimationItemsTaxesModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<SaleEstimationItemsTaxesModel> getSaleEstimationItemsTaxes(@PathVariable(value = "id") final String saleEstimationItemsTaxesId) {
		SaleEstimationItemsTaxesContext saleEstimationItemsTaxesContext = saleEstimationItemsTaxesContextFactory.getObject();

		SaleEstimationItemsTaxesModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(saleEstimationItemsTaxesId),
				saleEstimationItemsTaxesContext);
		return new ResponseEntity<SaleEstimationItemsTaxesModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "saleEstimationItemsTaxesBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<SaleEstimationItemsTaxesModel, SaleEstimationItemsTaxesContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setSaleEstimationItemsTaxesObjectFactory(final ObjectFactory<SaleEstimationItemsTaxesContext> saleEstimationItemsTaxesContextFactory) {
		this.saleEstimationItemsTaxesContextFactory = saleEstimationItemsTaxesContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
