package packageName;

import java.util.Collection;

import javax.annotation.Resource;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.arthvedi.bnv.user.businessdelegate.context.BnvUserOtpContext;
import com.arthvedi.bnv.user.model.BnvUserOtpModel;
import com.arthvedi.core.businessdelegate.IBusinessDelegate;
import com.arthvedi.core.businessdelegate.model.IKeyBuilder;
import com.arthvedi.core.businessdelegate.model.SimpleIdKeyBuilder;
import com.arthvedi.core.model.CollectionModelWrapper;
import com.arthvedi.core.model.IModelWrapper;
/**
*
*/
import com.google.code.siren4j.Siren4J;

/**
 * @author Administrator
 *
 */

@CrossOrigin("*")
@RestController
@RequestMapping(value = "/address", produces = "application/json", consumes = "application/json")
public class AddressController {

	private IBusinessDelegate<AddressModel, AddressContext, IKeyBuilder<String>, String> businessDelegate;
	private ObjectFactory<SimpleIdKeyBuilder> keyBuilderFactory;
	private ObjectFactory<AddressContext> addressContextFactory;

	@PostMapping(value = "/create")
	public ResponseEntity<AddressModel> createAddress(@RequestBody  AddressModel addressModel) {
	addressModel =	businessDelegate.create(addressModel);
		return new ResponseEntity<AddressModel>(addressModel, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/{id}/edit", method = RequestMethod.PUT)
	public ResponseEntity<AddressModel> edit(@PathVariable(value = "id") final String addressId,
			@RequestBody  AddressModel addressModel) {

	addressModel =	businessDelegate.edit(keyBuilderFactory.getObject().withId(addressId), addressModel);
		return new ResponseEntity<AddressModel>(addressModel, HttpStatus.OK);
	}

		@GetMapping(value = "/all")
	public ResponseEntity<Collection<AddressModel>> getAll() {
		AddressContext addressContext = addressContextFactory.getObject();
		Collection<AddressModel> addressModels = businessDelegate.getCollection(addressContext);
		
		return new ResponseEntity<Collection<AddressModel>>(addressModels, HttpStatus.OK);
	}

		@GetMapping(value = "/{id}")
	public ResponseEntity<AddressModel> getAddress(@PathVariable(value = "id") final String addressId) {
		AddressContext addressContext = addressContextFactory.getObject();

		AddressModel model = businessDelegate.getByKey(keyBuilderFactory.getObject().withId(addressId),
				addressContext);
		return new ResponseEntity<AddressModel>(model, HttpStatus.OK);
	}

	/**
	 * @param businessDelegate
	 */
	@Resource(name = "addressBusinessDelegate")
	public void setBusinessDelegate(
			final IBusinessDelegate<AddressModel, AddressContext, IKeyBuilder<String>, String> businessDelegate) {
		this.businessDelegate = businessDelegate;
	}

	@Autowired
	public void setAddressObjectFactory(final ObjectFactory<AddressContext> addressContextFactory) {
		this.addressContextFactory = addressContextFactory;
	}

	/**
	 * @param factory
	 */
	@Resource
	public void setKeyBuilderFactory(final ObjectFactory<SimpleIdKeyBuilder> factory) {
		keyBuilderFactory = factory;
	}

}
