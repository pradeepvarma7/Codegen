package packageName;

import com.waterapp.domain.GrnItemsTaxes;
import com.waterapp.model.GrnItemsTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("grnItemsTaxesToGrnItemsTaxesModelConverter")
public class GrnItemsTaxesToGrnItemsTaxesModelConverter
        implements Converter<GrnItemsTaxes, GrnItemsTaxesModel> {
    @Autowired
    private ObjectFactory<GrnItemsTaxesModel> grnItemsTaxesModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GrnItemsTaxesModel convert(final GrnItemsTaxes source) {
        GrnItemsTaxesModel grnItemsTaxesModel = grnItemsTaxesModelFactory.getObject();
        BeanUtils.copyProperties(source, grnItemsTaxesModel);

        return grnItemsTaxesModel;
    }

    @Autowired
    public void setGrnItemsTaxesModelFactory(
            final ObjectFactory<GrnItemsTaxesModel> grnItemsTaxesModelFactory) {
        this.grnItemsTaxesModelFactory = grnItemsTaxesModelFactory;
    }
}
