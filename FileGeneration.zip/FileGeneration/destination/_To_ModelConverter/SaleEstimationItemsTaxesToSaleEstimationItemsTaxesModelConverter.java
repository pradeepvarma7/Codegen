package packageName;

import com.waterapp.domain.SaleEstimationItemsTaxes;
import com.waterapp.model.SaleEstimationItemsTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("saleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter")
public class SaleEstimationItemsTaxesToSaleEstimationItemsTaxesModelConverter
        implements Converter<SaleEstimationItemsTaxes, SaleEstimationItemsTaxesModel> {
    @Autowired
    private ObjectFactory<SaleEstimationItemsTaxesModel> saleEstimationItemsTaxesModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public SaleEstimationItemsTaxesModel convert(final SaleEstimationItemsTaxes source) {
        SaleEstimationItemsTaxesModel saleEstimationItemsTaxesModel = saleEstimationItemsTaxesModelFactory.getObject();
        BeanUtils.copyProperties(source, saleEstimationItemsTaxesModel);

        return saleEstimationItemsTaxesModel;
    }

    @Autowired
    public void setSaleEstimationItemsTaxesModelFactory(
            final ObjectFactory<SaleEstimationItemsTaxesModel> saleEstimationItemsTaxesModelFactory) {
        this.saleEstimationItemsTaxesModelFactory = saleEstimationItemsTaxesModelFactory;
    }
}
