package packageName;

import com.waterapp.domain.GrnTaxes;
import com.waterapp.model.GrnTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("grnTaxesToGrnTaxesModelConverter")
public class GrnTaxesToGrnTaxesModelConverter
        implements Converter<GrnTaxes, GrnTaxesModel> {
    @Autowired
    private ObjectFactory<GrnTaxesModel> grnTaxesModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GrnTaxesModel convert(final GrnTaxes source) {
        GrnTaxesModel grnTaxesModel = grnTaxesModelFactory.getObject();
        BeanUtils.copyProperties(source, grnTaxesModel);

        return grnTaxesModel;
    }

    @Autowired
    public void setGrnTaxesModelFactory(
            final ObjectFactory<GrnTaxesModel> grnTaxesModelFactory) {
        this.grnTaxesModelFactory = grnTaxesModelFactory;
    }
}
