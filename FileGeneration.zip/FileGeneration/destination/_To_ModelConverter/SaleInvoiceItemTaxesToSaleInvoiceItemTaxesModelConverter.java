package packageName;

import com.waterapp.domain.SaleInvoiceItemTaxes;
import com.waterapp.model.SaleInvoiceItemTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("saleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter")
public class SaleInvoiceItemTaxesToSaleInvoiceItemTaxesModelConverter
        implements Converter<SaleInvoiceItemTaxes, SaleInvoiceItemTaxesModel> {
    @Autowired
    private ObjectFactory<SaleInvoiceItemTaxesModel> saleInvoiceItemTaxesModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public SaleInvoiceItemTaxesModel convert(final SaleInvoiceItemTaxes source) {
        SaleInvoiceItemTaxesModel saleInvoiceItemTaxesModel = saleInvoiceItemTaxesModelFactory.getObject();
        BeanUtils.copyProperties(source, saleInvoiceItemTaxesModel);

        return saleInvoiceItemTaxesModel;
    }

    @Autowired
    public void setSaleInvoiceItemTaxesModelFactory(
            final ObjectFactory<SaleInvoiceItemTaxesModel> saleInvoiceItemTaxesModelFactory) {
        this.saleInvoiceItemTaxesModelFactory = saleInvoiceItemTaxesModelFactory;
    }
}
