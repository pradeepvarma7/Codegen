package packageName;

import com.waterapp.domain.GrnItems;
import com.waterapp.model.GrnItemsModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("grnItemsToGrnItemsModelConverter")
public class GrnItemsToGrnItemsModelConverter
        implements Converter<GrnItems, GrnItemsModel> {
    @Autowired
    private ObjectFactory<GrnItemsModel> grnItemsModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GrnItemsModel convert(final GrnItems source) {
        GrnItemsModel grnItemsModel = grnItemsModelFactory.getObject();
        BeanUtils.copyProperties(source, grnItemsModel);

        return grnItemsModel;
    }

    @Autowired
    public void setGrnItemsModelFactory(
            final ObjectFactory<GrnItemsModel> grnItemsModelFactory) {
        this.grnItemsModelFactory = grnItemsModelFactory;
    }
}
