package packageName;

import com.waterapp.domain.SaleOrderItemsTaxes;
import com.waterapp.model.SaleOrderItemsTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("saleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter")
public class SaleOrderItemsTaxesToSaleOrderItemsTaxesModelConverter
        implements Converter<SaleOrderItemsTaxes, SaleOrderItemsTaxesModel> {
    @Autowired
    private ObjectFactory<SaleOrderItemsTaxesModel> saleOrderItemsTaxesModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public SaleOrderItemsTaxesModel convert(final SaleOrderItemsTaxes source) {
        SaleOrderItemsTaxesModel saleOrderItemsTaxesModel = saleOrderItemsTaxesModelFactory.getObject();
        BeanUtils.copyProperties(source, saleOrderItemsTaxesModel);

        return saleOrderItemsTaxesModel;
    }

    @Autowired
    public void setSaleOrderItemsTaxesModelFactory(
            final ObjectFactory<SaleOrderItemsTaxesModel> saleOrderItemsTaxesModelFactory) {
        this.saleOrderItemsTaxesModelFactory = saleOrderItemsTaxesModelFactory;
    }
}
