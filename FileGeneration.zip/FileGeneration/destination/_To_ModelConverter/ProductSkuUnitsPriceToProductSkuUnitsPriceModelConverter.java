package packageName;

import com.waterapp.domain.ProductSkuUnitsPrice;
import com.waterapp.model.ProductSkuUnitsPriceModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("productSkuUnitsPriceToProductSkuUnitsPriceModelConverter")
public class ProductSkuUnitsPriceToProductSkuUnitsPriceModelConverter
        implements Converter<ProductSkuUnitsPrice, ProductSkuUnitsPriceModel> {
    @Autowired
    private ObjectFactory<ProductSkuUnitsPriceModel> productSkuUnitsPriceModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public ProductSkuUnitsPriceModel convert(final ProductSkuUnitsPrice source) {
        ProductSkuUnitsPriceModel productSkuUnitsPriceModel = productSkuUnitsPriceModelFactory.getObject();
        BeanUtils.copyProperties(source, productSkuUnitsPriceModel);

        return productSkuUnitsPriceModel;
    }

    @Autowired
    public void setProductSkuUnitsPriceModelFactory(
            final ObjectFactory<ProductSkuUnitsPriceModel> productSkuUnitsPriceModelFactory) {
        this.productSkuUnitsPriceModelFactory = productSkuUnitsPriceModelFactory;
    }
}
