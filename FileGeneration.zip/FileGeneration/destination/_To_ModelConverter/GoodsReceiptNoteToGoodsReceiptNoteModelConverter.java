package packageName;

import com.waterapp.domain.GoodsReceiptNote;
import com.waterapp.model.GoodsReceiptNoteModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component("goodsReceiptNoteToGoodsReceiptNoteModelConverter")
public class GoodsReceiptNoteToGoodsReceiptNoteModelConverter
        implements Converter<GoodsReceiptNote, GoodsReceiptNoteModel> {
    @Autowired
    private ObjectFactory<GoodsReceiptNoteModel> goodsReceiptNoteModelFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GoodsReceiptNoteModel convert(final GoodsReceiptNote source) {
        GoodsReceiptNoteModel goodsReceiptNoteModel = goodsReceiptNoteModelFactory.getObject();
        BeanUtils.copyProperties(source, goodsReceiptNoteModel);

        return goodsReceiptNoteModel;
    }

    @Autowired
    public void setGoodsReceiptNoteModelFactory(
            final ObjectFactory<GoodsReceiptNoteModel> goodsReceiptNoteModelFactory) {
        this.goodsReceiptNoteModelFactory = goodsReceiptNoteModelFactory;
    }
}
