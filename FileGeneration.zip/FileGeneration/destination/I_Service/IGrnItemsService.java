package packageName;

import java.util.List;

import com.waterapp.domain.GrnItems;
/*
*@Author varma
*/
public interface IGrnItemsService {
	
	GrnItems create(GrnItems grnItems);

	void deleteGrnItems(String grnItemsId);

	GrnItems getGrnItems(String grnItemsId);

	List<GrnItems> getAll(GrnItemsContext grnItemsContext);

	GrnItems updateGrnItems(GrnItems grnItems);
}
