package packageName;

import java.util.List;

import com.waterapp.domain.GrnItemsTaxes;
/*
*@Author varma
*/
public interface IGrnItemsTaxesService {
	
	GrnItemsTaxes create(GrnItemsTaxes grnItemsTaxes);

	void deleteGrnItemsTaxes(String grnItemsTaxesId);

	GrnItemsTaxes getGrnItemsTaxes(String grnItemsTaxesId);

	List<GrnItemsTaxes> getAll(GrnItemsTaxesContext grnItemsTaxesContext);

	GrnItemsTaxes updateGrnItemsTaxes(GrnItemsTaxes grnItemsTaxes);
}
