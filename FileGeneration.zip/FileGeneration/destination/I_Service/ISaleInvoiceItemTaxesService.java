package packageName;

import java.util.List;

import com.waterapp.domain.SaleInvoiceItemTaxes;
/*
*@Author varma
*/
public interface ISaleInvoiceItemTaxesService {
	
	SaleInvoiceItemTaxes create(SaleInvoiceItemTaxes saleInvoiceItemTaxes);

	void deleteSaleInvoiceItemTaxes(String saleInvoiceItemTaxesId);

	SaleInvoiceItemTaxes getSaleInvoiceItemTaxes(String saleInvoiceItemTaxesId);

	List<SaleInvoiceItemTaxes> getAll(SaleInvoiceItemTaxesContext saleInvoiceItemTaxesContext);

	SaleInvoiceItemTaxes updateSaleInvoiceItemTaxes(SaleInvoiceItemTaxes saleInvoiceItemTaxes);
}
