package packageName;

import java.util.List;

import com.waterapp.domain.Address;
/*
*@Author varma
*/
public interface IAddressService {
	
	Address create(Address address);

	void deleteAddress(String addressId);

	Address getAddress(String addressId);

	List<Address> getAll(AddressContext addressContext);

	Address updateAddress(Address address);
}
