package packageName;

import java.util.List;

import com.waterapp.domain.GrnTaxes;
/*
*@Author varma
*/
public interface IGrnTaxesService {
	
	GrnTaxes create(GrnTaxes grnTaxes);

	void deleteGrnTaxes(String grnTaxesId);

	GrnTaxes getGrnTaxes(String grnTaxesId);

	List<GrnTaxes> getAll(GrnTaxesContext grnTaxesContext);

	GrnTaxes updateGrnTaxes(GrnTaxes grnTaxes);
}
