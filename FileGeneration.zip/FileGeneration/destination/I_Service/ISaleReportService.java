package packageName;

import java.util.List;

import com.waterapp.domain.SaleReport;
/*
*@Author varma
*/
public interface ISaleReportService {
	
	SaleReport create(SaleReport saleReport);

	void deleteSaleReport(String saleReportId);

	SaleReport getSaleReport(String saleReportId);

	List<SaleReport> getAll(SaleReportContext saleReportContext);

	SaleReport updateSaleReport(SaleReport saleReport);
}
