package packageName;

import java.util.List;

import com.waterapp.domain.ProductSkuUnitsPrice;
/*
*@Author varma
*/
public interface IProductSkuUnitsPriceService {
	
	ProductSkuUnitsPrice create(ProductSkuUnitsPrice productSkuUnitsPrice);

	void deleteProductSkuUnitsPrice(String productSkuUnitsPriceId);

	ProductSkuUnitsPrice getProductSkuUnitsPrice(String productSkuUnitsPriceId);

	List<ProductSkuUnitsPrice> getAll(ProductSkuUnitsPriceContext productSkuUnitsPriceContext);

	ProductSkuUnitsPrice updateProductSkuUnitsPrice(ProductSkuUnitsPrice productSkuUnitsPrice);
}
