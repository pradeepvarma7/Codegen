package packageName;

import java.util.List;

import com.waterapp.domain.SaleEstimationItemsTaxes;
/*
*@Author varma
*/
public interface ISaleEstimationItemsTaxesService {
	
	SaleEstimationItemsTaxes create(SaleEstimationItemsTaxes saleEstimationItemsTaxes);

	void deleteSaleEstimationItemsTaxes(String saleEstimationItemsTaxesId);

	SaleEstimationItemsTaxes getSaleEstimationItemsTaxes(String saleEstimationItemsTaxesId);

	List<SaleEstimationItemsTaxes> getAll(SaleEstimationItemsTaxesContext saleEstimationItemsTaxesContext);

	SaleEstimationItemsTaxes updateSaleEstimationItemsTaxes(SaleEstimationItemsTaxes saleEstimationItemsTaxes);
}
