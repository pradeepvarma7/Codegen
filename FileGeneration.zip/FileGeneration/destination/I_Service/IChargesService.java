package packageName;

import java.util.List;

import com.waterapp.domain.Charges;
/*
*@Author varma
*/
public interface IChargesService {
	
	Charges create(Charges charges);

	void deleteCharges(String chargesId);

	Charges getCharges(String chargesId);

	List<Charges> getAll(ChargesContext chargesContext);

	Charges updateCharges(Charges charges);
}
