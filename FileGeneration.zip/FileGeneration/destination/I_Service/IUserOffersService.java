package packageName;

import java.util.List;

import com.waterapp.domain.UserOffers;
/*
*@Author varma
*/
public interface IUserOffersService {
	
	UserOffers create(UserOffers userOffers);

	void deleteUserOffers(String userOffersId);

	UserOffers getUserOffers(String userOffersId);

	List<UserOffers> getAll(UserOffersContext userOffersContext);

	UserOffers updateUserOffers(UserOffers userOffers);
}
