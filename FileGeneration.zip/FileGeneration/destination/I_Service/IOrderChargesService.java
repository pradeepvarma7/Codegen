package packageName;

import java.util.List;

import com.waterapp.domain.OrderCharges;
/*
*@Author varma
*/
public interface IOrderChargesService {
	
	OrderCharges create(OrderCharges orderCharges);

	void deleteOrderCharges(String orderChargesId);

	OrderCharges getOrderCharges(String orderChargesId);

	List<OrderCharges> getAll(OrderChargesContext orderChargesContext);

	OrderCharges updateOrderCharges(OrderCharges orderCharges);
}
