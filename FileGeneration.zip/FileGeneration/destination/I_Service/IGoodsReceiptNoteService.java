package packageName;

import java.util.List;

import com.waterapp.domain.GoodsReceiptNote;
/*
*@Author varma
*/
public interface IGoodsReceiptNoteService {
	
	GoodsReceiptNote create(GoodsReceiptNote goodsReceiptNote);

	void deleteGoodsReceiptNote(String goodsReceiptNoteId);

	GoodsReceiptNote getGoodsReceiptNote(String goodsReceiptNoteId);

	List<GoodsReceiptNote> getAll(GoodsReceiptNoteContext goodsReceiptNoteContext);

	GoodsReceiptNote updateGoodsReceiptNote(GoodsReceiptNote goodsReceiptNote);
}
