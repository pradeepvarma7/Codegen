package packageName;

import java.util.List;

import com.waterapp.domain.Promotions;
/*
*@Author varma
*/
public interface IPromotionsService {
	
	Promotions create(Promotions promotions);

	void deletePromotions(String promotionsId);

	Promotions getPromotions(String promotionsId);

	List<Promotions> getAll(PromotionsContext promotionsContext);

	Promotions updatePromotions(Promotions promotions);
}
