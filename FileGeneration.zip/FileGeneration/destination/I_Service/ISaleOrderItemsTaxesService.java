package packageName;

import java.util.List;

import com.waterapp.domain.SaleOrderItemsTaxes;
/*
*@Author varma
*/
public interface ISaleOrderItemsTaxesService {
	
	SaleOrderItemsTaxes create(SaleOrderItemsTaxes saleOrderItemsTaxes);

	void deleteSaleOrderItemsTaxes(String saleOrderItemsTaxesId);

	SaleOrderItemsTaxes getSaleOrderItemsTaxes(String saleOrderItemsTaxesId);

	List<SaleOrderItemsTaxes> getAll(SaleOrderItemsTaxesContext saleOrderItemsTaxesContext);

	SaleOrderItemsTaxes updateSaleOrderItemsTaxes(SaleOrderItemsTaxes saleOrderItemsTaxes);
}
