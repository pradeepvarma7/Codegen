package packageName;

import java.util.List;

import com.waterapp.domain.BranchOrder;
/*
*@Author varma
*/
public interface IBranchOrderService {
	
	BranchOrder create(BranchOrder branchOrder);

	void deleteBranchOrder(String branchOrderId);

	BranchOrder getBranchOrder(String branchOrderId);

	List<BranchOrder> getAll(BranchOrderContext branchOrderContext);

	BranchOrder updateBranchOrder(BranchOrder branchOrder);
}
