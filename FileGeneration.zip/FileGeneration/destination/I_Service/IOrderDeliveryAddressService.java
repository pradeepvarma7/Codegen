package packageName;

import java.util.List;

import com.waterapp.domain.OrderDeliveryAddress;
/*
*@Author varma
*/
public interface IOrderDeliveryAddressService {
	
	OrderDeliveryAddress create(OrderDeliveryAddress orderDeliveryAddress);

	void deleteOrderDeliveryAddress(String orderDeliveryAddressId);

	OrderDeliveryAddress getOrderDeliveryAddress(String orderDeliveryAddressId);

	List<OrderDeliveryAddress> getAll(OrderDeliveryAddressContext orderDeliveryAddressContext);

	OrderDeliveryAddress updateOrderDeliveryAddress(OrderDeliveryAddress orderDeliveryAddress);
}
