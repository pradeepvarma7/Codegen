/**
 *
 */
package packageName;

import com.waterapp.domain.GoodsReceiptNote;
import com.waterapp.model.GoodsReceiptNoteModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("goodsReceiptNoteModelToGoodsReceiptNoteConverter")
public class GoodsReceiptNoteModelToGoodsReceiptNoteConverter implements Converter<GoodsReceiptNoteModel, GoodsReceiptNote> {
    @Autowired
    private ObjectFactory<GoodsReceiptNote> goodsReceiptNoteFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GoodsReceiptNote convert(final GoodsReceiptNoteModel source) {
        GoodsReceiptNote goodsReceiptNote = goodsReceiptNoteFactory.getObject();
        BeanUtils.copyProperties(source, goodsReceiptNote);

        return goodsReceiptNote;
    }

    @Autowired
    public void setGoodsReceiptNoteFactory(final ObjectFactory<GoodsReceiptNote> goodsReceiptNoteFactory) {
        this.goodsReceiptNoteFactory = goodsReceiptNoteFactory;
    }

}
