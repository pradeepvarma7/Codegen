/**
 *
 */
package packageName;

import com.waterapp.domain.GrnItemsTaxes;
import com.waterapp.model.GrnItemsTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("grnItemsTaxesModelToGrnItemsTaxesConverter")
public class GrnItemsTaxesModelToGrnItemsTaxesConverter implements Converter<GrnItemsTaxesModel, GrnItemsTaxes> {
    @Autowired
    private ObjectFactory<GrnItemsTaxes> grnItemsTaxesFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GrnItemsTaxes convert(final GrnItemsTaxesModel source) {
        GrnItemsTaxes grnItemsTaxes = grnItemsTaxesFactory.getObject();
        BeanUtils.copyProperties(source, grnItemsTaxes);

        return grnItemsTaxes;
    }

    @Autowired
    public void setGrnItemsTaxesFactory(final ObjectFactory<GrnItemsTaxes> grnItemsTaxesFactory) {
        this.grnItemsTaxesFactory = grnItemsTaxesFactory;
    }

}
