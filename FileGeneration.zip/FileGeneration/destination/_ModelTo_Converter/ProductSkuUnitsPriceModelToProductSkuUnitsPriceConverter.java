/**
 *
 */
package packageName;

import com.waterapp.domain.ProductSkuUnitsPrice;
import com.waterapp.model.ProductSkuUnitsPriceModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("productSkuUnitsPriceModelToProductSkuUnitsPriceConverter")
public class ProductSkuUnitsPriceModelToProductSkuUnitsPriceConverter implements Converter<ProductSkuUnitsPriceModel, ProductSkuUnitsPrice> {
    @Autowired
    private ObjectFactory<ProductSkuUnitsPrice> productSkuUnitsPriceFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public ProductSkuUnitsPrice convert(final ProductSkuUnitsPriceModel source) {
        ProductSkuUnitsPrice productSkuUnitsPrice = productSkuUnitsPriceFactory.getObject();
        BeanUtils.copyProperties(source, productSkuUnitsPrice);

        return productSkuUnitsPrice;
    }

    @Autowired
    public void setProductSkuUnitsPriceFactory(final ObjectFactory<ProductSkuUnitsPrice> productSkuUnitsPriceFactory) {
        this.productSkuUnitsPriceFactory = productSkuUnitsPriceFactory;
    }

}
