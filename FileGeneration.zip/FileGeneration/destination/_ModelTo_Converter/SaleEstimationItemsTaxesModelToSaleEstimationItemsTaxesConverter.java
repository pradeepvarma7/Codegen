/**
 *
 */
package packageName;

import com.waterapp.domain.SaleEstimationItemsTaxes;
import com.waterapp.model.SaleEstimationItemsTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("saleEstimationItemsTaxesModelToSaleEstimationItemsTaxesConverter")
public class SaleEstimationItemsTaxesModelToSaleEstimationItemsTaxesConverter implements Converter<SaleEstimationItemsTaxesModel, SaleEstimationItemsTaxes> {
    @Autowired
    private ObjectFactory<SaleEstimationItemsTaxes> saleEstimationItemsTaxesFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public SaleEstimationItemsTaxes convert(final SaleEstimationItemsTaxesModel source) {
        SaleEstimationItemsTaxes saleEstimationItemsTaxes = saleEstimationItemsTaxesFactory.getObject();
        BeanUtils.copyProperties(source, saleEstimationItemsTaxes);

        return saleEstimationItemsTaxes;
    }

    @Autowired
    public void setSaleEstimationItemsTaxesFactory(final ObjectFactory<SaleEstimationItemsTaxes> saleEstimationItemsTaxesFactory) {
        this.saleEstimationItemsTaxesFactory = saleEstimationItemsTaxesFactory;
    }

}
