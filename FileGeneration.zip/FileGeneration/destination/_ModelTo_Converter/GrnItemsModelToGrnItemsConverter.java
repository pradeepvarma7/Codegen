/**
 *
 */
package packageName;

import com.waterapp.domain.GrnItems;
import com.waterapp.model.GrnItemsModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("grnItemsModelToGrnItemsConverter")
public class GrnItemsModelToGrnItemsConverter implements Converter<GrnItemsModel, GrnItems> {
    @Autowired
    private ObjectFactory<GrnItems> grnItemsFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GrnItems convert(final GrnItemsModel source) {
        GrnItems grnItems = grnItemsFactory.getObject();
        BeanUtils.copyProperties(source, grnItems);

        return grnItems;
    }

    @Autowired
    public void setGrnItemsFactory(final ObjectFactory<GrnItems> grnItemsFactory) {
        this.grnItemsFactory = grnItemsFactory;
    }

}
