/**
 *
 */
package packageName;

import com.waterapp.domain.GrnTaxes;
import com.waterapp.model.GrnTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("grnTaxesModelToGrnTaxesConverter")
public class GrnTaxesModelToGrnTaxesConverter implements Converter<GrnTaxesModel, GrnTaxes> {
    @Autowired
    private ObjectFactory<GrnTaxes> grnTaxesFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public GrnTaxes convert(final GrnTaxesModel source) {
        GrnTaxes grnTaxes = grnTaxesFactory.getObject();
        BeanUtils.copyProperties(source, grnTaxes);

        return grnTaxes;
    }

    @Autowired
    public void setGrnTaxesFactory(final ObjectFactory<GrnTaxes> grnTaxesFactory) {
        this.grnTaxesFactory = grnTaxesFactory;
    }

}
