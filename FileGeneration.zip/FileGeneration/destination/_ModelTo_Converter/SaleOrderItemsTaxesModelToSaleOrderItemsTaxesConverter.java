/**
 *
 */
package packageName;

import com.waterapp.domain.SaleOrderItemsTaxes;
import com.waterapp.model.SaleOrderItemsTaxesModel;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author Jay
 *
 */
@Component("saleOrderItemsTaxesModelToSaleOrderItemsTaxesConverter")
public class SaleOrderItemsTaxesModelToSaleOrderItemsTaxesConverter implements Converter<SaleOrderItemsTaxesModel, SaleOrderItemsTaxes> {
    @Autowired
    private ObjectFactory<SaleOrderItemsTaxes> saleOrderItemsTaxesFactory;
    @Autowired
    private ConversionService conversionService;

    @Override
    public SaleOrderItemsTaxes convert(final SaleOrderItemsTaxesModel source) {
        SaleOrderItemsTaxes saleOrderItemsTaxes = saleOrderItemsTaxesFactory.getObject();
        BeanUtils.copyProperties(source, saleOrderItemsTaxes);

        return saleOrderItemsTaxes;
    }

    @Autowired
    public void setSaleOrderItemsTaxesFactory(final ObjectFactory<SaleOrderItemsTaxes> saleOrderItemsTaxesFactory) {
        this.saleOrderItemsTaxesFactory = saleOrderItemsTaxesFactory;
    }

}
